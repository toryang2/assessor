# ETRACS 2.54 / 2.55 — Phase 4.1: Data Integrity and Business-Rule Validation Matrix

> **Audit Scope:** `etracs254_kitaotao` Database | **Connection:** MySQL (`localhost:3306`, User: `chatgpt_ro`)  
> **Audit Mode:** Strict READ-ONLY (`SELECT` queries only, zero mutations/repairs/migrations; zero remote connections, zero application execution)  
> **Investigation Date:** October 2026 (Phase 4.1 Integrity Query and Evidence Correction Pass)  
> **Baseline Reference:** Phase 2 Verified Transaction Matrix, Phase 3.3 Lifecycle Matrix, & Phase 4 Validation Deliverables  

---

## 1. Executive Summary & Methodology

This report establishes the **Phase 4.1 Integrity Query and Evidence Correction Pass** for the ETRACS assessment system. Continuing from the initial Phase 4 validation, this pass corrects query grains, separates completeness from value reconciliation, provides bounded cycle testing, validates complete population cardinalities using NULL-safe operators, reconciles missing cancellation metadata tokens, and establishes rigorous multi-slice terminology.

### Verified Population Denominators
All measurements are strictly anchored to verified database table counts:
- **`faas` (Property Declarations):** **18,841 total records** (9,704 `CURRENT`, 8,899 `CANCELLED`, 228 `INTERIM`, 9 `FORAPPROVAL`, 1 `PENDING`).
- **`faas_previous` (Predecessor Linkages):** **18,855 total links** (9,241 electronic resolved, 9,586 recorded historical references with NULL ID, 28 unresolved populated IDs).
- **`rpu` (Real Property Units):** **18,843 total records** (18,841 linked to FAAS; 2 unlinked historical orphans).
- **`rpumaster` (Root Parcel Identity):** **27,661 total records** in base table; **10,121 distinct RPUMasters** referenced across active FAAS records.
- **`rpu_assessment` (Assessment Line Items):** **22,430 total lines** (0 orphans unlinked to RPU; spanning 18,828 distinct RPUs).
- **`rptledger` (Treasury Property Ledgers):** **10,241 total ledgers** (strictly 0 duplicate TD numbers).
- **`rptledgerfaas` (Ledger Assessment Slices):** **22,155 total slices** (verified mutually exclusive categorization summing exactly to 22,155).

---

## 2. Workstream 1 — FAAS & Predecessor Lineage Validation

### 2.1 Predecessor Link Modes in `faas_previous` (Query 1.1)
Historical predecessor connections across the **18,855 total rows** in `faas_previous` evaluate into three distinct evidential modes:

| Predecessor Link Mode | Predecessor FAAS ID Status | Predecessor RPU ID Status | Link Count | Pct of Links | Evidential Classification |
| :--- | :--- | :--- | :---: | :---: | :--- |
| **Electronic Resolution Mode** | Populated & Resolves to `faas.objid` | Populated & Resolves to `rpu.objid` | **9,241** | 49.01% | Directly supported by database evidence |
| **Recorded Historical Reference Mode** | `IS NULL` | `IS NULL` | **9,586** | 50.84% | Supported by client-code evidence (`initSuperseded` / reset) |
| **Unresolved Target Mode** | Populated but absent from `faas` | Populated but absent from `rpu` | **28** | 0.15% | **Confirmed referential-integrity issue** |

> [!NOTE]
> In 100% of the 18,855 rows, `prevfaasid` and `prevrpuid` share identical nullability and resolution status. The 28 unresolved links point to **20 distinct missing FAAS IDs** (e.g., `Fb1aa850:175df309598:-3e64`, `F-16983047:17017f1ff98:-1605`), representing historical unmigrated records or deleted draft declarations.

### 2.2 Predecessor Multiplicity & Branching (Query 1.2)
Evaluating predecessor rows per distinct FAAS record across all 18,841 FAAS:
- **Zero Predecessors (0 rows):** **27 FAAS records** (1 `CURRENT` GR, 6 `INTERIM` ND, 13 `CANCELLED` GR, 5 `INTERIM` GR, 1 `PENDING` CS, 1 `CANCELLED` RE).
- **Single Predecessor (1 row):** **18,776 FAAS records** (99.65%). Standard unit-continuation or restructuring transaction.
- **Dual Predecessors (2 rows):** **36 FAAS records** (Consolidations `CS`, `CS/SD`, and parcel merges).
- **Three Predecessors (3 rows):** **1 FAAS record** (`F5de3380f:19a70447287:-37d9`, TD `22-010-0001-06320`).
- **Four Predecessors (4 rows):** **1 FAAS record** (`F5de3380f:19a70447287:-343c`, TD `22-010-0001-06321`).

### 2.3 Self-Links, Bounded Cycle Detection, and Same-TD Links (Query 1.3A, 1.3B, 1.3C, 1.3D)
1. **Direct Self-Links (`faasid = prevfaasid`):** Exactly **2 records** in `faas_previous`:
   - `PF-fb9dbf5:18377264a5a:-70a3` (FAAS: `F-49edd98d:176d4e5e3cd:-6015`, TD `10-002-03980`, State `CANCELLED`).
   - `PF-6d83a19e:17273a8adae:-3cb2` (FAAS: `F63344efe:17273e405f2:-7113`, TD `10-001-09871`, State `CANCELLED`).
   - *Classification:* **Confirmed internal contradiction** (graph self-cycle).
2. **Direct Two-Way Cycles (Excluding Self-Links - Query 1.3C):**
   - Query 1.3C tests for direct mutual links ($A \to B$ and $B \to A$) with the explicit constraint `fp1.faasid != fp1.prevfaasid`.
   - **Executed Result:** Exactly **0 two-way cycles** detected.
3. **Bounded Three-Way Cycles (Excluding Self-Links - Query 1.3D):**
   - Query 1.3D tests for three-node cycles ($A \to B \to C \to A$) where no node is self-linked.
   - **Executed Result:** Exactly **0 three-way cycles** detected.
   - *Evidential Scope Limitation:* This result demonstrates that no direct 2-cycles or 3-cycles exist in stored identifiers; it does not claim the entire multi-hop historical graph is acyclic across arbitrary path depths without a recursive graph traversal.
4. **Same-TD Links (`faas.tdno = faas_previous.prevtdno` - Query 1.3B):** Exactly **17 records**. In client code (`RPUInfoPreviousRecordModel.groovy`), line 327 executes `if (entity.tdno == item.prevtdno) return;` to guard against initializing predecessors when TD numbers match. These 17 records represent legacy data entry or manual correction transactions where the same TD number was retained across revisions.
5. **Duplicate Predecessor Links:** Exactly **0 duplicate `(faasid, prevfaasid)` pairs** exist. Exactly **1 duplicate `(faasid, prevtdno)` link** exists (`PF4b509d42:18654505642:-3b45` and `PF4b509d42:18654505642:-3b47` under FAAS `F4b509d42:18654505642:-3b46`).

### 2.4 Lineage Agreement: `faas_previous` vs `rpu.previd` & `realproperty.previd` (Queries 1.4 & 1.5)
- **`rpu.previd` Agreement:** Across the 9,269 links with populated `prevrpuid`:
  - **8,731 links (94.20%)** match perfectly (`r.previd = fp.prevrpuid`).
  - **537 links (5.79%)** have `r.previd IS NULL` while `fp.prevrpuid` is populated (newly instantiated RPU roots in subdivisions and consolidations).
  - **1 link (0.01%)** demonstrates a direct ID mismatch (`PF4b509d42:18654505642:-3b45`: `r.previd` points to `RPU5c24dc5:16fe5927aa2:-68d1` while `fp.prevrpuid` records `RPU-14da9f13:178344cf792:248d`).
- **Land `realproperty.previd` Spatial Lineage:** Across 7,620 resolved land predecessor links:
  - **7,130 links (93.57%)** have `rp.previd` matching predecessor `realpropertyid`.
  - **12 links (0.16%)** reuse `realproperty` directly (`f.realpropertyid = pf.realpropertyid`).
  - **478 links (6.27%)** instantiate a new land parcel where `rp.previd IS NULL` (primarily Subdivisions `SD` and Transfers `TR`).
  - **0 links (0.00%)** demonstrate an asymmetric conflicting target pointer.

---

## 3. Workstream 2 — RPUMaster Population Validation & Pointer Integrity

### 3.1 Population Cardinality & Key Verification (Query 2.0)
Query 2.0 explicitly evaluates distinct keys across the relationship path `faas -> rpu -> rpumaster`:
- **Total `faas` rows:** **18,841**; distinct `f.objid`: **18,841**; distinct `f.rpuid`: **18,841**.
- **Joined `rpu` rows:** Distinct `r.objid`: **18,841**; distinct `r.rpumasterid`: **10,121**.
- **Joined `rpumaster` rows:** Distinct `rm.objid`: **10,121**.
- **Base table counts independently:**
  - `rpu`: **18,843 rows** (18,843 distinct `objid`; exactly 2 historical unlinked orphans: `RPU4e19689c:1775bec1612:a92` and `RPU5c24dc5:16fe44d2423:-2bc6`).
  - `rpumaster`: **27,661 rows** (27,661 distinct `objid`).
- *Cardinality Proof:* The relationship between `faas` and `rpu` is strictly **1:1** across the entire 18,841 active FAAS population (0 missing RPU foreign keys, 0 duplicate RPU associations). The relationship between `rpu` and `rpumaster` is **N:1** (18,841 RPUs map to 10,121 distinct RPUMaster parcel roots).

### 3.2 Rewritten Population & Four-Category Pointer Breakdown (Query 2.1)
Query 2.1 was rewritten with `LEFT JOIN`s and MySQL's NULL-safe comparison operator `<=>` to ensure missing relationships remain independently visible:

| FAAS State | Total FAAS | Missing RPU Rel | Missing RM Rel | Both Match (`<=>`) | Only FAAS Matches | Only RPU Matches | Neither Matches |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **`CURRENT`** | 9,704 | **0** | **0** | 9,617 (99.10%) | **0** | **0** | **87 (0.90%)** |
| **`CANCELLED`** | 8,899 | **0** | **0** | 187 (2.10%) | **0** | **0** | **8,712 (97.90%)** |
| **`INTERIM`** | 228 | **0** | **0** | 211 (92.54%) | **0** | **0** | **17 (7.46%)** |
| **`FORAPPROVAL`** | 9 | **0** | **0** | 9 (100.00%) | **0** | **0** | **0 (0.00%)** |
| **`PENDING`** | 1 | **0** | **0** | 0 (0.00%) | **0** | **0** | **1 (100.00%)** |
| **TOTAL** | **18,841** | **0** | **0** | **10,024 (53.20%)** | **0 (0.00%)** | **0 (0.00%)** | **8,817 (46.80%)** |

> [!IMPORTANT]
> **Zero Asymmetric Matches Invariant Confirmed:** Across all 18,841 FAAS records, exactly **0 records** match on `currentfaasid` alone and **0 records** match on `currentrpuid` alone. Pointers are maintained synchronously.

### 3.3 Categorization of the 87 `CURRENT` Pointer Mismatch Cases (Query 2.2)
The 87 cases where a `CURRENT` FAAS does not match its `rpumaster` pointers break down into five distinct target categories:

| Target Pointer Status | Count | Representative IDs | Status / Plausible Explanation |
| :--- | :---: | :--- | :--- |
| **Target Missing / Unmigrated** | **54** | `F-154c3657:1757306b8c7:-2ca6` (points to missing `F6cbfd73c:18735cdc683:3f45`) | **Unresolved; requires documentary or backend evidence.** `rpumaster` pointers target IDs absent from the database. |
| **Advanced to `INTERIM` Draft** | **13** | `F-12588285:18550d6a3b4:-2048` (points to `F-273574b2:19ea997a4f7:-5d5d`, TD `06454`) | **Unresolved hypothesis (supported by workflow state).** Pointers advanced when an unapproved draft revision was initiated. |
| **Target is `CANCELLED`** | **10** | `F-22a9e8dd:18ee9570f0d:1aef` (points to `CANCELLED` `F6cfdda65:185ec042e4b:4319`) | **Confirmed internal contradiction.** Active `CURRENT` record has pointers referencing an already cancelled predecessor. |
| **Advanced to Another `CURRENT`** | **6** | `F-3fd3e567:1750abd4a54:-6c7c` (points to `CURRENT` `F-5a4d8582:1879bf2818f:32ee`) | **Unresolved; requires documentary evidence.** Pointers advanced to a newer approved FAAS, but predecessor was never cancelled. |
| **Advanced to `FORAPPROVAL` Draft** | **4** | `F-2cd0fe3c:18599d4870a:669a` (points to `F-2a2841ba:188fa24d7ef:-1436`, TD `05234`) | **Unresolved hypothesis (supported by workflow state).** Pointers advanced during provincial approval review. |

---

## 4. Workstream 3 — Cancellation & Successor Consistency

### 4.1 Delimiter-Aware Cancellation Metrics (Query 3.1)
Across all **9,241 electronic predecessor links**:
- **Predecessor State is `CANCELLED`:** **9,199 links (99.55%)**; **42 links (0.45%)** point to predecessors not marked `CANCELLED`.
- **Predecessor `canceldate` Populated:** **9,203 links (99.59%)**; **38 links (0.41%)** have `canceldate IS NULL`.
- **Successor TD Matched in `cancelledbytdnos`:** **8,879 links (96.08%)** match using delimiter-aware matching (`FIND_IN_SET(TRIM(f.tdno), REPLACE(pf.cancelledbytdnos, ' ', '')) > 0`).
- **All Three Conditions Satisfied Simultaneously:** **8,868 links (95.96%)**.

### 4.2 Investigation of the 30 Links (28 Predecessors) Remaining `CURRENT` (Query 3.2)
The 42 links where the predecessor is not cancelled include 12 links where predecessor is `INTERIM` and exactly **30 links involving 28 distinct predecessor FAAS records** that remain in `CURRENT` state:
- **Successor is `INTERIM` Draft:** **21 links (19 predecessors)**. Unresolved hypothesis: predecessor remains `CURRENT` and taxable until the successor draft is formally approved.
- **Successor is `FORAPPROVAL` Draft:** **5 links (5 predecessors)**. Unresolved hypothesis: provincial review pending; property remains active under predecessor.
- **Successor is `CURRENT` (Dual-Active Conflict):** Exactly **4 links (4 predecessors)**:
  1. Pred `10-031-09440` (`CURRENT`) $\to$ Succ `22-010-0031-00269` (`CURRENT`, approved 2023-04-21).
  2. Pred `10-031-09454` (`CURRENT`) $\to$ Succ `22-010-0031-00273` (`CURRENT`, approved 2023-04-21).
  3. Pred `22-010-0001-01001` (`CURRENT`) $\to$ Succ `22-010-0001-05022` (`CURRENT`, approved 2023-02-21).
  4. Pred `10-001-02538` (`CURRENT`) $\to$ Succ `22-010-0001-00205` (`CURRENT`, approved 2023-01-09).
  - *Classification:* **Confirmed internal contradiction** (predecessor cancellation step omitted during successor approval).

### 4.3 Reconciled Missing Successor TD References in `cancelledbytdnos` (Query 3.3)
Query 3.3 explicitly executes against all predecessor links where the predecessor FAAS state is `CANCELLED`.
- **Eligible Denominator:** Exactly **9,199 links** (resolving to **8,872 distinct cancelled predecessor FAAS** and **9,188 distinct successor FAAS**).
- **Missing Successor TD Links:** Exactly **330 links** (3.59% of eligible links) satisfy both conditions:
  - Predecessor FAAS state is `CANCELLED`.
  - The successor TD token does not occur as an exact comma-separated token in `cancelledbytdnos`.
- **Component Grain & Token Breakdown:**
  - **330 links** across **104 distinct predecessor FAAS records** and **330 distinct successor FAAS records**.
  - **3 links:** Successor TD is NULL or blank.
  - **1 link:** Predecessor `cancelledbytdnos` is NULL or blank while successor TD is populated.
  - **326 links:** Predecessor `cancelledbytdnos` is populated, but the successor TD token is missing from the list.
- *Classification:* **Unresolved; workflow cause unverified.** The causal mechanism (whether batch cancellation, UI entry omission, or legacy script execution) cannot be proven without backend transaction logs.

---

## 5. Workstream 4 — Assessment & Treasury Integrity

### 5.1 Completeness Check: RPUs Without Assessment Lines (Query 4.2)
Kept strictly separate from value consistency checks:
- **Total `rpu` population:** **18,843 records**.
- **RPUs without assessment lines:** Exactly **15 records** (13 linked to FAAS, 2 unlinked orphans):
  - **2 `CURRENT` Land Lots:** `RPU-7e12f64e:1a12e268225:-7874` (TD `22-010-0001-09734`) and `RPU-7e12f64e:1a12e268225:-7af7` (TD `22-010-0001-09733`). Both represent child lots of a subdivision currently in draft completion.
  - **1 `CANCELLED` Improvement:** `RPU-49edd98d:176d4e5e3cd:-1e8f` (TD `10-006-09844`, building reassessment).
  - **10 `INTERIM` / `PENDING` Drafts:** Incomplete data capture drafts.
  - **2 Unlinked Historical RPUs:** `RPU4e19689c:1775bec1612:a92` and `RPU5c24dc5:16fe44d2423:-2bc6`.

### 5.2 Value Consistency: Evaluated ONLY for RPUs with Assessment Lines (Query 4.3)
Query 4.3 evaluates value consistency exclusively for the **18,828 RPUs** possessing at least one assessment line in `rpu_assessment` (**22,430 total lines**):

| Valuation Reconciliation Category | RPU Count | Pct of Evaluated | Min Difference | Max Difference | Average Difference | Evidential Status |
| :--- | :---: | :---: | :---: | :---: | :---: | :--- |
| **Exact Match ($\le 0.01$)** | **15,849** | 84.18% | ₱0.00 | ₱0.01 | ₱0.000001 | Directly supported by database evidence |
| **Difference $< 10$** | **2,974** | 15.80% | ₱0.02 | ₱5.00 | ₱2.60 | **Unresolved hypothesis (supported by calculation)** |
| **Difference $\ge 10$** | **5** | 0.03% | ₱350.00 | ₱2,070.00 | ₱838.32 | **Unresolved; requires documentary evidence** |
| **TOTAL EVALUATED** | **18,828** | **100.00%** | — | — | — | — |

> [!NOTE]
> **Component Verification for Difference $< 10$:** Inspection of component values shows that component assessments apply fractional statutory rates (e.g., $10.00\%$ on market values such as ₱102,431.13 producing unrounded line AV ₱10,243.11). When multiple components are summed and stored into `rpu.totalav`, rounding to the nearest ten pesos at the RPU total grain accounts for the delta (min ₱0.02, max ₱5.00, average ₱2.60). This is labeled an **unresolved hypothesis supported by component calculation**.
>
> The 5 large discrepancies ($\ge 10$) remain unexplained anomalies:
> 1. `RPU2acc2502:17501d45530:-66d7` (`CURRENT`, TD `10-031-09399`): `totalav = 150.00`, lines sum to `2,220.00` (diff: `-2,070.00`).
> 2. `RPU116f54e4:178c8807423:6a15` (`INTERIM`, TD `10-029-09559`): `totalav = 110.88`, lines sum to `942.48` (diff: `-831.60`).
> 3. `RPU1f1a5c7b:174f6d75476:2106` (`CANCELLED`, TD `10-009-08470`): `totalav = 280.00`, lines sum to `820.00` (diff: `-540.00`).
> 4. `RPU47d606b:17784196be3:2ee8` (`CANCELLED`, TD `10-013-10138`): `totalav = 1,390.00`, lines sum to `1,790.00` (diff: `-400.00`).
> 5. `RPU1f1a5c7b:174f6d75476:1b6e` (`CANCELLED`, TD `10-009-09114`): `totalav = 90.00`, lines sum to `440.00` (diff: `-350.00`).

### 5.3 Rewritten Treasury Slice Reconciliation (Query 4.4)
Query 4.4 was rewritten to use subquery `EXISTS` checks, ensuring zero join multiplication. The base row count was independently retrieved (**22,155 rows**), and the four mutually exclusive categories sum exactly to that denominator:

| Category # | Slice Categorization | Foreign Key `faasid` Status | TD Number Match Status | Row Count | Pct of Total | Verified Sum Check |
| :---: | :--- | :--- | :--- | :---: | :---: | :---: |
| **Cat 1** | **Populated Resolving Slices** | Populated & Resolves to `faas.objid` | — | **18,920** | 85.39% | $\checkmark$ Part of 22,155 |
| **Cat 2** | **Populated Unresolved Slices** | Populated but absent from `faas` | — | **510** | 2.30% | $\checkmark$ Part of 22,155 |
| **Cat 3** | **NULL/Blank ID Matching TD** | `IS NULL` or blank | Matches active `faas.tdno` | **2,426** | 10.95% | $\checkmark$ Part of 22,155 |
| **Cat 4** | **NULL/Blank ID Nonmatching TD**| `IS NULL` or blank | Absent from active `faas.tdno` | **299** | 1.35% | $\checkmark$ Part of 22,155 |
| **TOTAL** | **All Categories Summed** | — | — | **22,155** | **100.00%** | **$18,920 + 510 + 2,426 + 299 = 22,155$** |

> [!NOTE]
> Category 2 references exactly **505 distinct missing FAAS IDs**. Category 3 represents historical assessment slices where the declaration was migrated into ETRACS without populating the foreign key `faasid`. Category 4 represents pre-ETRACS declarations retired prior to system adoption.

### 5.4 Repeated Pairs & Temporal Multi-Slice Breakdown (Query 4.5B & 4.5C)
To correct terminology, repeated `(rptledgerid, faasid)` slices are evaluated across distinct pairs, total rows, and excess rows, followed by explicit inspection of `fromyear`, `toyear`, `fromqtr`, and `toqtr`:
- **Total distinct repeated pairs:** Exactly **157 pairs**.
- **Total rows belonging to repeated pairs:** Exactly **489 rows**.
- **Excess rows above one per pair:** Exactly **332 excess rows** ($489 - 157 = 332$).
- **Temporal Bounds Inspection (Query 4.5C):**
  - **124 pairs (78.98%):** Span **distinct year bounds** (e.g., from 2019 to 2020 vs 2021 to 2022). Unresolved hypothesis: multi-year sequential tax assessment periods.
  - **32 pairs (20.38%):** Share **exact identical year and quarter bounds** (e.g., both slices cover 2019 Q1 to 2022 Q4). Unresolved hypothesis: supplemental assessments, backtax penalties (`backtax = 1`), or duplicate slice postings.
  - **1 pair (0.64%):** Shares the same year span but distinct quarter bounds (`F2e9ced45:1729cfde703:-7f65`).

---

## 6. Workstream 5 — Exception Classification Summary

The updated exception catalog in [`etracs_data_integrity_exceptions.csv`](file:///d:/CODE/assessor/etracs-scripts/etracs_data_integrity_exceptions.csv) reconciles all 18 exception groups with corrected denominators and rigorous classifications:

| Exception Group | Category | Anomaly Description | Count | Denominator | Corrected Classification |
| :--- | :--- | :--- | :---: | :---: | :--- |
| **EXC-01** | Lineage | Broken `prevfaasid` FK in `faas_previous` | 28 | 18,855 links | Confirmed referential-integrity issue |
| **EXC-02** | Lineage | Direct self-link (`faasid = prevfaasid`) | 2 | 18,855 links | Confirmed internal contradiction |
| **EXC-03** | Lineage | Same-TD link (`tdno = prevtdno`) | 17 | 18,855 links | Unusual but plausibly legitimate |
| **EXC-04** | RPUMaster | Current pointers reference missing record | 54 | 9,704 CURRENT | Unresolved; requires documentary evidence |
| **EXC-05** | RPUMaster | Current pointers advanced to draft | 17 | 9,704 CURRENT | Unresolved hypothesis (supported by workflow state) |
| **EXC-06** | RPUMaster | Current pointers reference cancelled FAAS | 10 | 9,704 CURRENT | Confirmed internal contradiction |
| **EXC-07** | RPUMaster | Pointers advanced to another CURRENT | 6 | 9,704 CURRENT | Unresolved; requires documentary evidence |
| **EXC-08** | Cancellation| Predecessor remains CURRENT (Dual-active) | 4 | 9,241 links | Confirmed internal contradiction |
| **EXC-09** | Cancellation| Predecessor CURRENT while successor draft | 26 | 9,241 links | Unresolved hypothesis (supported by workflow state) |
| **EXC-10** | Cancellation| Successor TD missing in `cancelledbytdnos` | 330 | 9,199 eligible links | Unresolved; workflow cause unverified |
| **EXC-11** | Assessment | RPUs with zero assessment lines | 15 | 18,843 total RPUs | Unusual but plausibly legitimate |
| **EXC-12** | Assessment | Minor AV rounding delta ($< 10$ pesos) | 2,974 | 18,828 RPUs w/ lines| Unresolved hypothesis (supported by calculation) |
| **EXC-13** | Assessment | Significant AV discrepancy ($\ge 10$ pesos)| 5 | 18,828 RPUs w/ lines| Unresolved; requires documentary evidence |
| **EXC-14** | Treasury | Broken `faasid` FK in `rptledgerfaas` | 510 | 22,155 slices | Confirmed referential-integrity issue |
| **EXC-15** | Treasury | Legacy slices with NULL ID, matched TD | 2,426 | 22,155 slices | Expected or supported historical pattern |
| **EXC-16** | Treasury | Retired slices with NULL ID, unmatched TD | 299 | 22,155 slices | Expected or supported historical pattern |
| **EXC-17** | Treasury | FAAS linked to multiple distinct ledgers | 2 | 18,841 FAAS | Confirmed internal contradiction |
| **EXC-18** | Treasury | Repeated `(ledgerid, faasid)` pairs | 157 pairs (489 rows)| 22,155 slices | Unusual but plausibly legitimate |

---

## 7. Phase 4.1 Correction Log & Evidence Reconciliations

| # | Item / Claim Area | Phase 4 Finding | Phase 4.1 Corrected Finding | Evidential Basis & Status |
|---|---|---|---|---|
| **1** | **Cycle Detection** | Included self-links in 2-cycle results. | Excluded self-links (`faasid != prevfaasid`); reported 0 direct two-way cycles and 0 three-way cycles. Qualified as bounded cycle test, not proof of acyclic graph. | Executed SQL (Queries 1.3C & 1.3D): Direct 2-cycles = 0, Direct 3-cycles = 0. |
| **2** | **Treasury Slice Categorization** | LEFT JOINs without explicit uniqueness check. | Rewritten with `EXISTS` subqueries; independently validated base row count (22,155) and proved the 4 mutually exclusive categories sum exactly to 22,155 ($18,920 + 510 + 2,426 + 299$). | Executed SQL (Query 4.4): Exactly 22,155 slices reconciled. |
| **3** | **RPUMaster Population & 1:1 Claim** | Relying on equal row counts. | Validated distinct keys (18,841 FAAS to 18,841 RPUs to 10,121 RPUMasters); base table has 27,661 RPUMasters. Rewrote Query 2.1 with `LEFT JOIN` and `<=>` operator (0 missing RPU, 0 missing RPUMaster). | Executed SQL (Queries 2.0 & 2.1): Proven 1:1 FAAS-to-RPU and N:1 RPU-to-RPUMaster. |
| **4** | **Assessment Completeness vs Consistency** | Evaluated RPUs without lines together with AV reconciliation. | Separated completeness (15 RPUs without lines, Query 4.2) from value consistency (18,828 RPUs with lines, Query 4.3). Attributed difference $< 10$ to rounding only as an unresolved hypothesis supported by component rate calculations. | Executed SQL (Queries 4.2 & 4.3): 15,849 exact, 2,974 diff $<10$, 5 diff $\ge 10$. |
| **5** | **Missing Successor TD References** | Reported 327 links with mismatched denominator. | Addressed eligible denominator: 9,199 links where predecessor is CANCELLED. Found 330 links (across 104 pred FAAS, 330 succ FAAS; 3 succ TD blank, 1 cancelledby blank, 326 token missing). Denominator corrected to 9,199. | Executed SQL (Query 3.3): 330 links / 9,199 eligible links. |
| **6** | **Repeated Slices & Root Causes** | Referred to 157 pairs as "duplicates" and assumed backtaxes. | Distinguished 157 pairs, 489 total rows, and 332 excess rows. Inspected temporal bounds: 124 pairs have distinct year spans, 32 have identical year/quarter spans, 1 has distinct quarters. Removed unsupported causal claims; labeled as hypotheses. | Executed SQL (Queries 4.5B & 4.5C): Rigorous slice breakdown. |

---

## 8. Appendix — Confirmed Findings vs Unresolved Hypotheses

### Confirmed Database Findings (Direct Proof)
1. **Broken Foreign Keys Exist in Legacy Tables:** Exactly 28 rows in `faas_previous` reference 20 missing FAAS records; exactly 510 rows in `rptledgerfaas` reference 505 missing FAAS records.
2. **Zero Asymmetric Matches Invariant:** Across 18,841 FAAS records, RPUMaster pointers are strictly synchronized: exactly 0 asymmetric matches exist where one pointer matches and the other fails.
3. **Dual-Active Conflicts:** Exactly 4 predecessor FAAS records remain in `CURRENT` state despite having electronic successors that are also active and approved in `CURRENT` state.
4. **Assessment Orphan Impossibility:** Zero orphan records exist in `rpu_assessment`; all 22,430 lines resolve to active `rpu` entities.
5. **Ledger Uniqueness Invariant:** `rptledger.tdno` contains strictly zero duplicate TD numbers across all 10,241 records. Matched FAAS-to-ledger records are strictly 1:1 on both sides.

### Unresolved Hypotheses (Requiring Documentary or Backend Evidence)
1. **Origin of the 54 Missing RPUMaster Target IDs:** Whether the 54 `CURRENT` records whose pointers target missing FAAS IDs were caused by incomplete database migration scripts or manual database deletions cannot be determined from the database snapshot alone.
2. **Root Cause of the 5 Large Assessment Discrepancies:** Whether the 5 historical records with AV differences $\ge 10$ pesos represent manual database updates or legacy software bugs prior to 2022 cannot be proven without backend change logs.
3. **Multi-Ledger Linkage Mechanism:** The 2 FAAS records linked to multiple ledgers (`10-001-03489` and `10-009-12207`) likely stem from conflicting manual ledger mapping updates, but the exact historical sequence remains uninspected.
4. **Causes of Missing Successor TD Tokens in Cancelled Records:** The exact reason why 330 links lack successor TD tokens in `cancelledbytdnos` (batch cancellation, script migration, or manual omission) remains unproven.
