# ETRACS 2.54 — Phase 3.2: Final Lifecycle Evidence & Query Corrective Matrix

> **Audit Scope:** `etracs254_kitaotao` Database | **Connection:** MySQL 5.7+ (`localhost:3306`, User: `chatgpt_ro`)  
> **Audit Mode:** Strict READ-ONLY (`SELECT` queries only, zero mutations/repairs/migrations)  
> **Investigation Date:** October 2026 (Phase 3.2 Final Corrective Pass)  
> **Baseline Reference:** Phase 2 Verified Transaction Matrix & Master Inventory  

---

## 1. Executive Summary & Methodology

This report presents the **Phase 3.2 Final Lifecycle Evidence and Query Corrective Pass** for the ETRACS 2.54 real property assessment database of the Municipality of Kitaotao. Building upon the Phase 3.1 corrective baseline, this pass resolves the remaining query-grain issues, eliminates arbitrary aggregation functions, provides a four-category RPUMaster pointer breakdown across all lifecycle states, reconciles cancellation date discrepancies, re-evaluates operational table linkage paths, and appropriately classifies business rules based strictly on direct database observations.

### Core Lifecycle Dimensions Analyzed
For every active transaction type, the data model was evaluated across ten relational dimensions:
1. **Source FAAS, RPU, and RealProperty Records:** Predecessor entity discovery and electronic resolution vs recorded references with NULL or unresolved IDs.
2. **Resulting FAAS, RPU, and RealProperty Records:** Entity creation, state, and inheritance.
3. **Observed FAAS & RPU Lifecycle States:** Distribution of `CURRENT`, `CANCELLED`, `INTERIM`, `FORAPPROVAL`, and `PENDING`.
4. **Predecessor Linkage Modes (`faas_previous`):** Electronic resolution vs recorded references with NULL or unresolved IDs.
5. **RPU & RealProperty Continuity Pointers (`rpu.previd` & `realproperty.previd`):** Lineage tracking and spatial inheritance at distinct FAAS vs link grains.
6. **RPUMaster Pointer Mechanics (`rpumaster`):** Full-population four-category pointer breakdown and lifecycle state pointer analysis.
7. **Cancellation Synchronization & Successor References:** Reconciled metadata consistency, `canceldate` populations, and delimiter-aware matching in `cancelledbytdnos`.
8. **Assessment Detail Changes (`rpu_assessment`):** Valuation trajectories, reachable predecessor lines via `rpu.previd`, and association patterns.
9. **Treasury Ledger Integration (`rptledger` & `rptledgerfaas`):** In-place ledger reuse vs fresh ledger issuance, reported at true deduplicated association grain without arbitrary selection.
10. **Audit Trail & Module Tables:** Modification tracking in `rpt_changeinfo` and observation of operational table states and linkages.

---

## 2. Task 1 — Active Transaction Types & Record Suitability

The Kitaotao database contains exactly **27 configured transaction types** in `faas_txntype`, of which **17 transaction types** are populated in the live `faas` table across **18,841 total records**. Exactly 10 configured transaction types have 0 records (`CA`, `CD`, `CK`, `CT`, `MCS`, `PC`, `ST`, `STP`, `TRY`, `UK`).

All 27 configured transaction types were queried directly by LEFT JOINing from `faas_txntype` (Query 1.1).

### Complete Configured Transaction Types & Record Suitability

| Txn Code | Configured Name | Total FAAS | CURRENT | CANCELLED | Transitional / Draft | With TD No | Suitable Finalized Records | Observed States |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| `GR` | General Revision | 15,468 | 8,372 | 7,033 | 63 | 15,450 | 15,405 (99.6%) | `CANCELLED`, `CURRENT`, `FORAPPROVAL`, `INTERIM` |
| `ND` | New Discovery | 1,669 | 740 | 801 | 128 | 1,662 | 1,541 (92.3%) | `CANCELLED`, `CURRENT`, `INTERIM` |
| `RE` | Reassessment | 513 | 28 | 479 | 6 | 512 | 507 (98.8%) | `CANCELLED`, `CURRENT`, `FORAPPROVAL`, `INTERIM` |
| `SD` | Subdivision | 423 | 173 | 227 | 23 | 423 | 400 (94.6%) | `CANCELLED`, `CURRENT`, `FORAPPROVAL`, `INTERIM` |
| `TR` | Transfer of Ownership | 352 | 148 | 200 | 4 | 349 | 348 (98.9%) | `CANCELLED`, `CURRENT`, `FORAPPROVAL`, `INTERIM` |
| `CE` | Correction of Entry | 304 | 194 | 100 | 10 | 301 | 294 (96.7%) | `CANCELLED`, `CURRENT`, `INTERIM` |
| `DC` | Data Capture | 29 | 13 | 16 | 0 | 29 | 29 (100.0%) | `CANCELLED`, `CURRENT` |
| `CC` | Change Classification | 20 | 9 | 9 | 2 | 20 | 18 (90.0%) | `CANCELLED`, `CURRENT`, `FORAPPROVAL`, `INTERIM` |
| `RV` | Revision | 19 | 5 | 14 | 0 | 19 | 19 (100.0%) | `CANCELLED`, `CURRENT` |
| `CS/SD` | Consolidation/Subdivision | 13 | 5 | 8 | 0 | 13 | 13 (100.0%) | `CANCELLED`, `CURRENT` |
| `TRC` | Transfer with Correction | 12 | 4 | 7 | 1 | 12 | 11 (91.7%) | `CANCELLED`, `CURRENT`, `INTERIM` |
| `RS` | Resection | 8 | 8 | 0 | 0 | 8 | 8 (100.0%) | `CURRENT` |
| `CS` | Consolidation | 4 | 3 | 0 | 1 | 3 | 3 (75.0%) | `CURRENT`, `PENDING` |
| `CTD` | Cancellation | 2 | 2 | 0 | 0 | 2 | 2 (100.0%) | `CURRENT` |
| `MC` | Multiple Claim | 2 | 0 | 2 | 0 | 2 | 2 (100.0%) | `CANCELLED` |
| `TRE` | Transfer with Reassessment | 2 | 0 | 2 | 0 | 2 | 2 (100.0%) | `CANCELLED` |
| `DT` | Destruction of Property | 1 | 0 | 1 | 0 | 1 | 1 (100.0%) | `CANCELLED` |
| `CA` | Change Assessment | 0 | 0 | 0 | 0 | 0 | 0 (N/A) | *None (Unpopulated)* |
| `CD` | Change Description | 0 | 0 | 0 | 0 | 0 | 0 (N/A) | *None (Unpopulated)* |
| `CK` | Change Cadastral / Lot / Survey No. | 0 | 0 | 0 | 0 | 0 | 0 (N/A) | *None (Unpopulated)* |
| `CT` | Change Taxability | 0 | 0 | 0 | 0 | 0 | 0 (N/A) | *None (Unpopulated)* |
| `MCS` | Multiple Claim Settlement | 0 | 0 | 0 | 0 | 0 | 0 (N/A) | *None (Unpopulated)* |
| `PC` | Physical Change | 0 | 0 | 0 | 0 | 0 | 0 (N/A) | *None (Unpopulated)* |
| `ST` | Segregation | 0 | 0 | 0 | 0 | 0 | 0 (N/A) | *None (Unpopulated)* |
| `STP` | Special Transfer | 0 | 0 | 0 | 0 | 0 | 0 (N/A) | *None (Unpopulated)* |
| `TRY` | Transfer with Segregation | 0 | 0 | 0 | 0 | 0 | 0 (N/A) | *None (Unpopulated)* |
| `UK` | Unknown | 0 | 0 | 0 | 0 | 0 | 0 (N/A) | *None (Unpopulated)* |
| **TOTAL** | **27 Configured Types** | **18,841** | **9,704** | **8,899** | **238** | **18,808** | **18,603 (98.7%)** | — |

> [!NOTE]
> **Record Suitability Criteria (Reproduced via Query 1.1):** Suitable finalized records require an applicable finalized state (`CURRENT` or `CANCELLED`), a non-empty `tdno`, and resolvable foreign key relationships to both `rpu` and `realproperty`. Across the total population of 18,841 FAAS records, **18,603 records (98.7%)** satisfy all suitability criteria. The remaining 238 records are unapproved transitional drafts (`INTERIM`: 228, `FORAPPROVAL`: 9, `PENDING`: 1), of which 33 lack a generated TD number.

---

## 3. Task 2 — Entity Lifecycle & Relationship Mapping

### 3.1 The Three Structural Transaction Archetypes

Empirical analysis reveals that the 17 active transaction types divide into three core structural archetypes based on how they treat the underlying real property entity, the RPU identity, and the treasury tax ledger:

```
+--------------------------------------------------------------------------------------------------+
| ARCHETYPE 1: UNIT-CONTINUATION (Lineage Preservation)                                             |
| Transactions: GR, TR, CE, CC, TRC                                                                |
| - rpumaster: Preserved. r.rpumasterid points to persistent root RPU.                             |
| - realproperty: Reused or linked via rp.previd.                                                  |
| - rptledger: Reused in-place (rl.tdno updated; multi-year history preserved in rptledgerfaas).  |
| - Multiplicity: Almost strictly 1:1.                                                             |
+--------------------------------------------------------------------------------------------------+
                                                |
+--------------------------------------------------------------------------------------------------+
| ARCHETYPE 2: UNIT-RESTRUCTURING (Spatial & Legal Restructuring)                                  |
| Transactions: SD, CS, CS/SD, RS                                                                 |
| - rpumaster: Newly created (rm.objid = r.rpumasterid = r.objid) for each resulting parcel.      |
| - realproperty: New parcel entities created for child lots; or reused shared host land.          |
| - rptledger: New ledgers issued for newly created property units; predecessor ledgers closed out. |
| - Multiplicity: 1:N (Subdivision) or N:1 / N:M (Consolidation, Consolidation/Subdivision).      |
+--------------------------------------------------------------------------------------------------+
                                                |
+--------------------------------------------------------------------------------------------------+
| ARCHETYPE 3: BASELINE-ESTABLISHMENT & STATUS-CHANGE                                              |
| Transactions: ND, DC, RE, CTD, MC, TRE, DT, RV                                                   |
| - ND & DC: Establish new property units (new rpumaster, fresh ledger, no electronic pred).       |
| - CTD: Formally cancels property taxability (sets taxable=0, AV=0, marks predecessor cancelled).  |
| - DT: Formally records destruction/loss of improvements, adjusting assessed values downwards.   |
| - MC: Tracks conflicting land claims, later resolved into standard general revisions.           |
+--------------------------------------------------------------------------------------------------+
```

---

### 3.2 Relational Mapping Across the Ten Dimensions

#### 1. Source Entities & Predecessor Discovery
- **Linkage Repository:** Historical linkages are maintained in `faas_previous` (**18,855 total rows**) and denormalized into `faas.prevtdno`. The dedicated table `previousfaas` is **0 rows**.
- **Three-Category Predecessor Linkage Modes:**
  1. **Electronic Resolution Mode (`prevfaasid` populated and resolves):** **9,241 rows (49.0%)**. In 100% of these rows, `fp.prevrpuid` also resolves to `rpu.objid`.
  2. **Recorded Historical Reference Mode (`prevfaasid IS NULL`):** **9,586 rows (50.8%)**. A recorded `prevtdno` proves that a historical TD reference was documented. It does **not** establish whether the source was a physical tax declaration book, an un-migrated predecessor system, or an unrecorded electronic draft. Provenance is classified as *Recorded historical reference (electronic ID NULL)* unless case-specific documentary evidence (such as a book volume/page annotation in the memoranda) exists.
  3. **Unresolved Target Mode (`prevfaasid` populated but does not resolve):** **28 rows (0.15%)**. Broken foreign key references pointing to missing FAAS IDs.

#### 2. Resulting Entities & State Inheritance
- Every approved transaction creates a new `faas` record and an instantiated `rpu` record.
- **State Progression:** In observed completed records, transactions begin in `INTERIM`, transition through provincial review (`FORAPPROVAL` / `PENDING`), and become `CURRENT` upon approval. Predecessors are transitioned to `CANCELLED`.

#### 3. RPUMaster Pointer Mechanics: Four-Category Consistency Breakdown (Query 2.1 & 2.2)
- Evaluated across the **full population of 18,841 FAAS records** via `LEFT JOIN`:
  - **18,841 records (100.0%)** have an associated `rpu` relationship.
  - **18,841 records (100.0%)** have an associated `rpumaster` relationship via `r.rpumasterid`.
- **Four-Category Consistency Breakdown Across Entire Database:**
  - **Both Pointers Match (`currentfaasid = f.objid AND currentrpuid = f.rpuid`):** **10,024 records (53.2%)**.
  - **Only `currentfaasid` Matches:** **0 records (0.0%)**.
  - **Only `currentrpuid` Matches:** **0 records (0.0%)**.
  - **Neither Pointer Matches:** **8,817 records (46.8%)**.
- **Pointer Consistency Grouped by FAAS Lifecycle State (Query 2.2):**
  - **`CURRENT` (9,704 records):**
    - Both match: **9,617 (99.1%)**.
    - Only FAAS: **0 (0.0%)**.
    - Only RPU: **0 (0.0%)**.
    - Neither matches: **87 (0.9%)**. *(These 87 records represent cases where an RPUMaster was repointed to a newer draft or superseded parcel).*
  - **`CANCELLED` (8,899 records):**
    - Both match: **187 (2.1%)**. *(Historical parcels where RPUMaster pointers were retained upon cancellation).*
    - Neither matches: **8,712 (97.9%)**. *(Expected behavior: RPUMaster pointers naturally move forward to point to the active successor).*
  - **`INTERIM` (228 records):** Both match: **211 (92.5%)**; Neither matches: **17 (7.5%)**.
  - **`FORAPPROVAL` (9 records):** Both match: **9 (100.0%)**; Neither matches: **0 (0.0%)**.
  - **`PENDING` (1 record):** Both match: **0 (0.0%)**; Neither matches: **1 (100.0%)**.
- **Pointer Invariant:** In 100% of examined cases (18,841 of 18,841), `currentfaasid` and `currentrpuid` match jointly; there are **0 records** in the database where one pointer matches while the other differs.

#### 4. RealProperty Continuity: Distinct FAAS vs Predecessor Links (Query 2.3 & 2.4)
- **Predecessor Link Grain vs FAAS Record Grain:**
  - Total FAAS records examined: **18,841 distinct records**.
  - Total predecessor links in `faas_previous`: **18,855 rows** (9,241 electronic resolved links, 9,586 links with NULL predecessor ID, and 28 links with unresolved populated predecessor ID).
- **Land-Only Spatial Continuity (Query 2.4):**
  - Explicitly filtering by `r.rputype = 'land'` encompasses **13,136 distinct land FAAS records** and **13,121 land predecessor links**.
  - Of these, exactly **6,765 land links** resolve electronically:
    - **1 link** reuses `realproperty` directly (`f.realpropertyid = pf.realpropertyid`).
    - **6,753 links** create a new `realproperty` record that points directly to the predecessor land parcel (`rp.previd = pf.realpropertyid`).
    - **11 links** create an independent `realproperty` record (`rp.previd IS NULL` or points elsewhere).
- **Improvements (Buildings & Machinery):** Improvements do not chain parcel boundaries; `f.realpropertyid` directly references the host land parcel upon which the improvement is situated.

#### 5. Cancellation Synchronization & Metadata Reconciliation (Query 2.7)
- Across all **9,241 electronic predecessor links** (resolving to **8,902 distinct predecessor FAAS records**):
  - **Predecessor `state = 'CANCELLED'`:** **9,199 links** (8,872 distinct FAAS).
  - **Predecessor `canceldate` Populated:** Exactly **9,203 links** (resolving to **8,877 distinct predecessor FAAS records**). Exactly **38 links** (25 distinct predecessor FAAS) have `canceldate IS NULL`.
    - *Reconciliation Note:* The previously reported 8,878 count represented distinct predecessor FAAS meeting date conditions under narrower joins; the exact database count on all 9,241 electronic predecessor links is **9,203 links (8,877 distinct predecessor FAAS)** with populated `canceldate`. Across all 8,899 `CANCELLED` FAAS records in the entire database, 8,891 have a populated `canceldate` and 8 have `canceldate IS NULL`.
  - **Successor TD Match in `cancelledbytdnos`:** **8,879 links** (8,879 distinct FAAS) match via delimiter-aware matching (`FIND_IN_SET`).
  - **Three-Condition Joint Cancellation Measure:** Exactly **8,868 links (96.0%)**, resolving to **8,868 distinct predecessor FAAS records**, satisfy **all three conditions simultaneously** (`state = 'CANCELLED'`, `canceldate IS NOT NULL`, and `FIND_IN_SET(TRIM(f.tdno), REPLACE(pf.cancelledbytdnos, ' ', '')) > 0`).
  - **Anomalous Retention:** Exactly **30 links**, resolving to **28 distinct predecessor FAAS records**, remain in `CURRENT` state despite having electronic successors.

#### 6. Valuation Continuity & Trajectory Grain (Query 2.5)
- All valuation comparisons across predecessor relationships are evaluated at the **predecessor-link comparison grain** (not unique transactions).
- Across the **8,306 electronic predecessor-link comparisons** in General Revisions (`GR`):
  - In **1,257 link comparisons (15.1%)**, successor assessed value is exactly equal to predecessor assessed value.
  - In **7,030 link comparisons (84.6%)**, successor assessed value increased.
  - In **19 link comparisons (0.2%)**, successor assessed value decreased.
  - Successor market value matched predecessor market value in **1,241 link comparisons (14.9%)**.
- In Transfers of Ownership (`TR`), **147 electronic link comparisons** were evaluated: **146 link comparisons (99.3%)** demonstrated exact valuation conservation.

#### 7. Treasury Ledger Integration & Deduplicated Association Grain (Query 2.6)
To avoid artificial row multiplication and eliminate arbitrary aggregation selection (such as `MIN(objid)`), treasury ledger associations were evaluated by direct join on `tdno`:
- **Unique TD Key in Ledger Table:** `rptledger` contains **10,241 total records** and **10,241 distinct TD numbers** (exactly **0 duplicate TD numbers** in `rptledger`). Thus, join on `tdno` is strictly 1:1.
- **Distinct FAAS Records Examined:** **18,841**.
- **FAAS Records Matching a Ledger:** Exactly **9,752 distinct FAAS records** match a ledger record by TD number.
- **Distinct Ledgers Matching FAAS TD Numbers:** Exactly **9,752 distinct ledger records** match an active FAAS record. (The remaining 489 ledgers in `rptledger` belong to historical TD numbers not present in `faas.tdno`).
- **FAAS Records Without Resolvable Ledger:** **9,089 records** (predominantly cancelled historical FAAS or unapproved drafts).
- **Independent Ledger Assessment Slices (`rptledgerfaas`):**
  - Total records in `rptledgerfaas` table: **22,155 rows**.
  - Total slices linked to active FAAS records (`rlf.faasid = f.objid`): **18,920 slices** across **18,591 distinct FAAS records**.
- **Fresh Ledger vs Reused Ledger Evidence (Deduplicated Association Grain):**
  - **Fresh Ledger Issuance (`rl.objid = f.objid`):** Observed in **1,418 FAAS records** (including 736 `ND`, 467 `GR`, and 174 `SD` records), where the ledger entity is instantiated sharing the FAAS object ID.
  - **Existing Ledger In-Place Reuse (`rl.objid != f.objid`):** Observed in **8,334 FAAS records** (including 7,947 `GR` and 139 `TR` records), where an existing ledger entity is maintained and its `tdno` pointer is updated.

#### 8. Assessment Continuity & Reachable Predecessor Lines (Query 2.8)
- **Observed Association Pattern:**
  - Total assessment-line records in `rpu_assessment`: **22,430 rows** (all 22,430 are distinct `objid`s).
  - Distinct RPU associations: **18,828 distinct RPUs** (13 FAAS/RPUs lack assessment lines).
  - Distinct FAAS associations: **18,828 distinct FAAS records**.
  - Reachable predecessor assessment lines via `rpu.previd`: **8,739 FAAS records** have `rpu.previd IS NOT NULL`, of which **8,719 FAAS records** successfully reach **10,434 distinct predecessor assessment lines**.
- **Evidential Boundary:** The presence of distinct `rpu_assessment` rows for new RPUs demonstrates a persistent multi-row assessment structure. However, snapshot data alone cannot prove that assessment rows were never modified in place during draft or transitional phases prior to final posting.

#### 9. Audit Trail & Operational Table Utilization (Query 2.9 & 2.10)
- **Audit Logging (`rpt_changeinfo` - Query 2.9):**
  - **Total rows in table:** **4,139 rows**.
  - **Resolved FAAS links:** **4,042 rows** resolve directly to **2,427 distinct active FAAS records**.
  - **Unresolved / Historical orphan rows:** **97 rows** reference **64 distinct FAAS IDs** that do not exist in the active `faas` table.
- **Operational Module Tables (Query 2.10):**
  - `subdivision`: Contains **14 rows** (`state = 'DRAFT'`), linked to transitional/draft FAAS records. Exactly **0 rows** link to completed (`CURRENT` or `CANCELLED`) FAAS records. Child tables `subdividedland`, `subdivision_motherland`, and `subdivisionaffectedrpu` contain **0 rows**.
  - `consolidation`: Contains **1 row** (`state = 'DRAFT'`), linked to a transitional draft FAAS. Exactly **0 rows** link to completed FAAS records. Child tables `consolidatedland` and `consolidationaffectedrpu` contain **0 rows**.
  - `cancelledfaas`: Contains **18 rows** (14 `APPROVED`, 2 `FORAPPROVAL`, 2 `DRAFT`). Exactly **14 rows** link to finalized completed FAAS records, and **4 rows** are unlinked/orphan.
  - **Evidential Classification:** In the current database snapshot, 400 finalized subdivisions (`SD`) and 3 finalized consolidations (`CS`) exist in `faas` without corresponding completed rows in `subdivision` or `consolidation`. This is classified as an **observed state in the current snapshot**, not conclusive proof of architectural bypass or obsolescence.

---

## 4. Task 3 — Representative Transaction Case Studies

A comprehensive catalog of representative cases was compiled into [`etracs_transaction_lifecycle_cases.csv`](file:///d:/CODE/assessor/etracs-scripts/etracs_transaction_lifecycle_cases.csv). Entity grains and ledger relationships were verified using Query 3.1:

### 4.1 Unit-Continuation: Transfer of Ownership (`TR`)
- **Case Reference:** `22-010-0032-05511` (FAAS: `F-6defdc2a:18e5560fd65:-5377`, State: `CURRENT`)
- **Predecessor:** `22-010-0032-00072` (FAAS: `Fd2d2dc1:185a34938e5:-4c48`, State: `CANCELLED`)
- **Lifecycle Relationships:**
  - `faas_previous`: 1 electronic link (`PF-6defdc2a:18e5560fd65:-5376`) resolving to predecessor FAAS and RPU.
  - `rpumaster`: Preserved root pointer (`r.rpumasterid = 'RPUd2d2dc1:185a34938e5:-4c45'`).
  - `realproperty`: New parcel created (`RP-6defdc2a:18e5560fd65:-5375`) with `previd` pointing to predecessor parcel (`RPd2d2dc1:185a34938e5:-4c46`).
  - **Valuation Conservation:** Predecessor AV: ₱9,600.00 (MV: ₱192,000.00); Successor AV: **₱9,600.00** (MV: ₱192,000.00) — **100% exact valuation conservation**.
  - **Treasury Linkage:** `rptledger` reused in-place (`F1f1a5c7b:174f6d75476:-439b`), updated `tdno = '22-010-0032-05511'`. Successor slice added to `rptledgerfaas` starting in 2025.

### 4.2 Unit-Restructuring: Subdivision (`SD`)
- **Mother Lot:** `22-010-0003-00131` (FAAS: `F-3618ea4e:1866d2fd03c:-5212`, State: `CANCELLED`)
- **Child Lots:** 13 child lots created (`22-010-0003-05100` to `05112`).
- **Representative Child Lot:** `22-010-0003-05103` (FAAS: `F1c487f07:1879300ce47:-2b1e`, State: `CURRENT`)
- **Lifecycle Relationships:**
  - `faas_previous`: 1 electronic link resolving to mother lot `F-3618ea4e:1866d2fd03c:-5212`.
  - `rpumaster`: Newly instantiated root (`rm.objid = r.rpumasterid = r.objid`).
  - `realproperty`: Newly created parcel entity (`RP1c487f07:1879300ce47:-2b1d`).
  - **Treasury Linkage:** Each child lot generates an independent fresh `rptledger` (`rl.objid = f.objid`), establishing separate tax liability for each partitioned parcel.
  - **Operational Table Status:** Mother lot and child lots possess **0 rows** in `subdividedland`, `subdivision_motherland`, and `subdivisionaffectedrpu`.

### 4.3 Unit-Restructuring: Pure Consolidation (`CS`)
- **Case Reference:** `22-010-0001-05825` (FAAS: `F-3c37d1fb:190c848694a:-475c`, State: `CURRENT`)
- **Predecessors:** `22-010-0001-00316` (AV: ₱35,210.00) and `22-010-0001-00318` (AV: ₱70,100.00). Both marked `CANCELLED` on 2024-07-19 with `cancelledbytdnos = '22-010-0001-05825'`.
- **Lifecycle Relationships:**
  - `faas_previous`: 2 electronic links resolving to both predecessor FAAS records.
  - `realproperty`: Both predecessors and successor represent machinery installed on the same shared host land parcel (`RP-2cd0fe3c:1859914a4be:-7ab3`, Cadastral Lot `87-B-6`).
  - **Valuation Conservation:** Predecessor Market Values (₱44,010.00 + ₱87,628.80) sum to **₱131,638.80**. Consolidated FAAS MV is **₱131,638.80 (100% MV conservation)**. Consolidated AV is **₱105,300.00** across 3 re-broken machinery line items (₱10 rounding delta).
  - **Operational Table Status:** The dedicated `consolidation` table contains 0 active records (1 draft record only); the consolidation was executed through core FAAS tables.

### 4.4 Status-Change: Formal Tax Cancellation (`CTD`)
- **Case Reference:** `22-010-0022-05368` (FAAS: `F-65f9b252:18b59c10494:-36b1`, State: `CURRENT`)
- **Predecessor:** `22-010-0022-00147` (FAAS: `F2711f584:18773251b9a:-79f7`, State: `CANCELLED`)
- **Lifecycle Relationships:**
  - `rpu`: Market value retained (₱137,970.00), but `r.taxable` set to `0` and `r.totalav` set to `₱0.00`.
  - `rpu_assessment`: Assessment level set to `0.00%` and assessed value set to `₱0.00`.
  - **Business Purpose:** Formally retires property from the tax roll while preserving complete historical auditability.

---

## 5. Task 4 — Business Rule Classification & Evidence Standards

Each proposed business rule was systematically reviewed and classified into one of five standard evidential categories:
1. **Directly established by the current database snapshot**
2. **Observed in the selected cases or examined population**
3. **Supported by service-code evidence** *(N/A: packaged JAR is unavailable)*
4. **Inferred but not established**
5. **Unknown or contradicted by the available evidence**

| Business Rule / Claim | Status | Evidential Classification | Supporting Evidence & Scope |
| :--- | :---: | :--- | :--- |
| **BR-01: Historical TD Reference Rule** | **REVISED** | Directly established by the current database snapshot | A populated `prevtdno` proves a historical TD was recorded (18,855 rows). It does *not* prove physical-book provenance. 9,241 resolve electronically; 9,586 have NULL predecessor ID (provenance unestablished without case notes); 28 are unresolved populated IDs. |
| **BR-02: RPUMaster Pointer Consistency** | **CONFIRMED** | Directly established by the current database snapshot | Four-category breakdown: exactly 10,024 FAAS match both pointers; 0 match only FAAS; 0 match only RPU; 8,817 match neither (8,712 CANCELLED, 87 CURRENT, 17 INTERIM, 1 PENDING). Pointer consistency is joint in 100% of cases. |
| **BR-03: Assessment Replacement Model** | **DOWNGRADED** | Observed in the selected cases or examined population | Assessment lines in `rpu_assessment` are observed tied to specific `rpuid` instances (22,430 lines across 18,828 RPUs). While cross-transaction replacements generate fresh lines, the claim that lines are *never* updated in place across intermediate drafts is an unproven lifecycle hypothesis. |
| **BR-04: State Progression Uniformity** | **REVISED** | Observed in the selected cases or examined population | While `INTERIM` -> `FORAPPROVAL`/`PENDING` -> `CURRENT` is observed across normal workflows, the snapshot cannot prove every historical transaction underwent identical intermediate steps. |
| **BR-05: Treasury Ledger In-Place Reuse** | **CONFIRMED** | Directly established by the current database snapshot | Reused in-place across 8,334 FAAS records (7,947 `GR`, 139 `TR`, where `rl.objid != f.objid`). Fresh ledgers issued for 1,418 records (736 `ND`, 467 `GR`, 174 `SD`, where `rl.objid = f.objid`). |
| **BR-06: Operational Wizard Table Bypass** | **REVISED** | Inferred but not established | All 400 finalized subdivisions and 3 consolidations lack corresponding completed rows in `subdivision`/`consolidation`. However, empty or draft-only tables represent snapshot observations, not proof of architectural bypass or obsolescence. |
| **BR-07: Valuation Conservation in Transfers** | **CONFIRMED** | Observed in the selected cases or examined population | 146 of 147 electronic predecessor-link comparisons in `TR` (99.3%) demonstrate exact valuation conservation. 1 case had a minor reassessment adjustment. |
| **BR-08: Complete Audit Log Tracking** | **REVISED** | Inferred but not established | `rpt_changeinfo` contains 4,139 rows covering 2,427 distinct FAAS across 14 transaction types. It is active, but not comprehensive across all 18,841 historical transactions (97 rows reference orphan FAAS IDs). |

---

## 6. Task 5 — Packaged Service Code Limitations

- **Search Scope:** Comprehensive searches across local workspace directories (`d:\CODE\assessor`, `etracs-scripts`) confirmed that `rameses-gov-etracs-rptis-services.jar` is **not available in the local repository**.
- **Evidence Boundary:** In accordance with mandatory constraints, all findings and classifications in Phase 3.2 are derived **strictly from direct database evidence**. Packaged-service-code evidence is documented as unavailable, and no unverified claims regarding service implementations are asserted.

---

## 7. Deliverables Index & Artifact References

The following companion deliverables have been updated in place for Phase 3.2:

1. [`etracs_transaction_lifecycle_matrix.md`](file:///d:/CODE/assessor/etracs-scripts/etracs_transaction_lifecycle_matrix.md): This comprehensive overview of transaction behavior, structural archetypes, corrected query grains, and classified business rules.
2. [`etracs_transaction_lifecycle_cases.csv`](file:///d:/CODE/assessor/etracs-scripts/etracs_transaction_lifecycle_cases.csv): Structured catalog of verified representative cases across all 17 active transaction types with explicit per-reference predecessor classifications.
3. [`etracs_transaction_lifecycle_queries.sql`](file:///d:/CODE/assessor/etracs-scripts/etracs_transaction_lifecycle_queries.sql): Executable SQL script containing all targeted read-only queries with deduplicated joins, four-category RPUMaster breakdown, and reproducibility queries.

---

## 8. Phase 3.2 Evidence & Query Correction Log

| Item / Claim Area | Phase 3.1 Status | Phase 3.2 Corrected Finding | Corrective Action & Supporting Query |
| :--- | :--- | :--- | :--- |
| **1. Treasury Ledger Aggregation** | Used `MIN(objid)` grouped by `tdno` in Query 2.6 and 3.1. | Replaced with direct join on `tdno`. Confirmed `rptledger` has 10,241 rows and 10,241 distinct TD numbers (0 duplicate TD numbers). Exactly 9,752 distinct FAAS match 9,752 distinct ledgers. Fresh: 1,418 (`rl.objid = f.objid`); Reused: 8,334 (`rl.objid != f.objid`). Total `rptledgerfaas` rows in DB: 22,155 (18,920 linked to active FAAS). | Rewrote Queries 2.6 and 3.1 in `etracs_transaction_lifecycle_queries.sql` without `MIN(objid)`. Updated Section 3.2 (Item 7). |
| **2. Assessment Replacement Model (BR-03)** | Claimed rows are "never updated in place". | Downgraded to observed association pattern: 22,430 distinct lines across 18,828 RPUs/FAAS; 8,719 FAAS reach 10,434 predecessor assessment lines via `rpu.previd`. Proving in-place overwrites never occur during drafting is an unproven hypothesis without audit logs or service code. | Downgraded BR-03 classification in Section 5. Added Query 2.8 reachable lines breakdown. |
| **3. RPUMaster Consistency (BR-02)** | Reported binary consistency (10,024 matched). | Added explicit four-category breakdown across full population and by state: Both match: 10,024; Only FAAS matches: 0; Only RPU matches: 0; Neither matches: 8,817 (8,712 CANCELLED, 87 CURRENT, 17 INTERIM, 1 PENDING). Explained that pointer differences on historical records represent expected progression to current parcels. | Rewrote Queries 2.1 and 2.2 with four categories. Updated Section 3.2 (Item 3) and BR-02. |
| **4. Operational Table & Denominator Reconciliations** | Claimed "all 423 subdivisions are completed". | Reconciled denominations: 423 total SD FAAS (173 `CURRENT`, 227 `CANCELLED`, 23 transitional). Total completed SD is 400 (not 423). Verified `subdivision` (14 drafts, 0 completed) and `consolidation` (1 draft, 0 completed). Reclassified empty/draft tables as snapshot observations, not proof of architectural bypass. | Corrected denominators in Section 2, Section 3.2 (Item 9), and BR-06. |
| **5. Cancellation Date Counts Reconciliation** | Reported 8,878 populated dates on electronic links. | Reran exact query on all 9,241 electronic links: 9,203 links (8,877 distinct predecessor FAAS) have populated `canceldate`; 38 links (25 distinct FAAS) have `canceldate IS NULL`. Exactly 8,868 links (8,868 distinct FAAS / 96.0%) meet all three conditions simultaneously. | Updated Section 3.2 (Item 5) and Query 2.7 with explicit link and distinct FAAS counts. |
| **6. Predecessor Classification in CSV** | Used mixed labels (`Unresolved/Snapshot`). | Preserved explicit three-category classifications for all cases: `Electronic (Resolved)`, `NULL ID (Recorded Reference)`, `Unresolved (Populated ID Not Found)`. Aligned per-reference statuses for multi-source cases and added EX-GR-03 for unresolved populated ID. | Updated `etracs_transaction_lifecycle_cases.csv` and Query 3.2 in `etracs_transaction_lifecycle_queries.sql`. |

### Unresolved Questions & Artifact Constraints
1. **Physical-Book Verification:** Without physical tax declaration registry books or digitized scan archives, the true provenance of the 9,586 records with `prevfaasid IS NULL` cannot be definitively confirmed by database queries alone.
2. **Service JAR Availability:** The backend service package `rameses-gov-etracs-rptis-services.jar` remains unavailable in the repository; business rules governing transitional workflow constraints, in-place drafting behavior, and wizard table dispatch logic remain inferred from database snapshot states rather than verified against service code.
