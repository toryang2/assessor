<?php

class Assessor_Settings {

	private $upload_dir;
	private $logo_folder = 'assessor-settings';
	private $allowed_image_types = array('jpg', 'jpeg', 'png', 'gif', 'webp');
	private $max_image_size = 5 * 1024 * 1024; // 5MB

	public function __construct() {
		$this->upload_dir = wp_upload_dir();
	}

	public function get_settings() {
		global $wpdb;
		$table = $wpdb->prefix . 'assessor_settings';
		$settings = $wpdb->get_row("SELECT * FROM $table ORDER BY id DESC LIMIT 1", ARRAY_A);
		if (!$settings) {
			$settings = array(
				'app_logo_url' => '',
				'header_photo_url' => '',
				'header_province' => 'BUKIDNON',
				'header_municipality' => 'KITAOTAO',
				'municipality_prefix' => 'GBL',
				'lgu_pin' => '059-10',
				'header_office' => 'OFFICE OF THE MUNICIPAL ASSESSOR',
				'request_place_issued_default' => '',
				'verifier_signatory_name' => '',
				'verifier_signatory_title' => '',
				'municipal_assessor_name' => '',
				'municipal_assessor_license' => '',
				'municipal_assessor_title' => '',
				'municipal_assessor_suffix' => '',
				'afk_timeout' => 30,
				'enable_etracs_features' => 0
			);
		}
		// Ensure municipal_assessor_license is always returned as a string to preserve leading zeros
		if (isset($settings['municipal_assessor_license'])) {
			error_log('🔍 SETTINGS: Raw license from DB = ' . var_export($settings['municipal_assessor_license'], true));
			error_log('🔍 SETTINGS: License type = ' . gettype($settings['municipal_assessor_license']));
			$settings['municipal_assessor_license'] = (string) $settings['municipal_assessor_license'];
			error_log('🔍 SETTINGS: After string cast = ' . var_export($settings['municipal_assessor_license'], true));
		}
		
		// Cast integer keys properly
		if (isset($settings['afk_timeout'])) {
			$settings['afk_timeout'] = intval($settings['afk_timeout']);
		}
		if (isset($settings['enable_etracs_features'])) {
			$settings['enable_etracs_features'] = intval($settings['enable_etracs_features']);
		}
		
		// Add ETRACS sync settings from wp_options
		$settings['assessor_etracs_db_host'] = get_option('assessor_etracs_db_host', 'localhost');
		$settings['assessor_etracs_db_port'] = get_option('assessor_etracs_db_port', '3306');
		$settings['assessor_etracs_db_user'] = get_option('assessor_etracs_db_user', 'root');
		$settings['assessor_etracs_db_password'] = get_option('assessor_etracs_db_password', '');
		$settings['assessor_etracs_db_name'] = get_option('assessor_etracs_db_name', 'etracs254_kitaotao');
		$settings['assessor_etracs_last_sync'] = get_option('assessor_etracs_last_sync', null);

		// Rewrite URLs dynamically based on requesting host for local builds
		if (defined('ASSESSOR_IS_LOCAL_BUILD') && ASSESSOR_IS_LOCAL_BUILD) {
			$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
			$current_host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
			$local_base = rtrim($protocol . $current_host, '/');
			
			if (!empty($settings['app_logo_url'])) {
				if (preg_match('/^https?:\/\/[^\/]+(\/wp-content\/uploads\/.*)$/i', $settings['app_logo_url'], $matches)) {
					$settings['app_logo_url'] = $local_base . $matches[1];
				}
			}
			if (!empty($settings['header_photo_url'])) {
				if (preg_match('/^https?:\/\/[^\/]+(\/wp-content\/uploads\/.*)$/i', $settings['header_photo_url'], $matches)) {
					$settings['header_photo_url'] = $local_base . $matches[1];
				}
			}
		}

		return Assessor_Public_API::append_public_api_settings($settings);
	}

	public function save_settings($request) {
		$params = $request->get_json_params();
		if (!$params) {
			$params = $request->get_params();
		}

		$allowed_keys = array('app_logo_url','header_photo_url','header_province','header_municipality','municipality_prefix','lgu_pin','header_office','request_place_issued_default','verifier_signatory_name','verifier_signatory_title','municipal_assessor_name','municipal_assessor_license','municipal_assessor_suffix','municipal_assessor_title','afk_timeout', 'enable_etracs_features');
		$uppercase_keys = array('verifier_signatory_name','verifier_signatory_title','municipal_assessor_name','municipal_assessor_license','municipal_assessor_suffix','municipal_assessor_title');
		$integer_keys = array('afk_timeout', 'enable_etracs_features');
		$data = array();
		foreach ($allowed_keys as $key) {
			if (isset($params[$key])) {
				if (in_array($key, $integer_keys, true)) {
					$val = intval($params[$key]);
					// Ensure afk_timeout is within valid range (5-480 minutes)
					if ($key === 'afk_timeout' && ($val < 5 || $val > 480)) {
						$val = 30; // Default to 30 minutes if invalid
					}
				} else {
					// Special handling for municipal_assessor_license to preserve leading zeros
					if ($key === 'municipal_assessor_license') {
						$val = is_string($params[$key]) ? $params[$key] : '';
						// Don't sanitize or uppercase the license to preserve leading zeros
					} else {
						$val = is_string($params[$key]) ? sanitize_text_field($params[$key]) : '';
						if (in_array($key, $uppercase_keys, true)) {
							$val = strtoupper($val);
						}
					}
				}
				$data[$key] = $val;
				
			}
		}
		if (empty($data)) {
			return $this->get_settings();
		}
		global $wpdb;
		$table = $wpdb->prefix . 'assessor_settings';
		$existing_id = $wpdb->get_var("SELECT id FROM $table ORDER BY id DESC LIMIT 1");
		if ($existing_id) {
			$wpdb->update($table, $data, array('id' => $existing_id));
		} else {
			$wpdb->insert($table, $data);
		}
		
		// Save ETRACS sync settings to wp_options
		$etracs_keys = array('assessor_etracs_db_host', 'assessor_etracs_db_port', 'assessor_etracs_db_user', 'assessor_etracs_db_password', 'assessor_etracs_db_name');
		foreach ($etracs_keys as $key) {
			if (isset($params[$key])) {
				update_option($key, sanitize_text_field($params[$key]));
			}
		}

		// Sync removed for settings
		return $this->get_settings();
	}

	public function upload_logo($request) {
		// Validate file
		if (!isset($_FILES['logo']) || $_FILES['logo']['error'] !== UPLOAD_ERR_OK) {
			return new WP_Error('upload_error', 'No file uploaded or upload error occurred', array('status' => 400));
		}

		$file = $_FILES['logo'];
		if ($file['size'] > $this->max_image_size) {
			return new WP_Error('file_too_large', 'Image exceeds 5MB limit', array('status' => 400));
		}

		$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
		if (!in_array($ext, $this->allowed_image_types)) {
			return new WP_Error('invalid_file_type', 'Only images are allowed (jpg, jpeg, png, gif, webp)', array('status' => 400));
		}

		// Ensure folder exists under uploads
		$base_dir = trailingslashit($this->upload_dir['basedir']) . $this->logo_folder;
		$base_url = trailingslashit($this->upload_dir['baseurl']) . $this->logo_folder;
		if (!file_exists($base_dir)) {
			if (!wp_mkdir_p($base_dir)) {
				return new WP_Error('dir_creation_failed', 'Failed to create settings upload directory', array('status' => 500));
			}
		}

		$filename = 'logo_' . time() . '_' . wp_generate_password(6, false) . '.' . $ext;
		$path = $base_dir . '/' . $filename;

		if (!move_uploaded_file($file['tmp_name'], $path)) {
			return new WP_Error('move_failed', 'Failed to move uploaded logo', array('status' => 500));
		}

		$url = $base_url . '/' . $filename;

		// Remove previously saved logo if it exists and is inside our settings folder
		global $wpdb;
		$settings_table = $wpdb->prefix . 'assessor_settings';
		$old_url = $wpdb->get_var("SELECT app_logo_url FROM $settings_table ORDER BY id DESC LIMIT 1");
		if (!empty($old_url) && $old_url !== $url) {
			$old_path = str_replace($this->upload_dir['baseurl'], $this->upload_dir['basedir'], $old_url);
			$old_path = wp_normalize_path($old_path);
			$safe_base = wp_normalize_path($base_dir);
			if (strpos($old_path, $safe_base) === 0 && file_exists($old_path)) {
				@unlink($old_path);
			}
		}

		// Persist to settings table
		$table = $wpdb->prefix . 'assessor_settings';
		$existing_id = $wpdb->get_var("SELECT id FROM $table ORDER BY id DESC LIMIT 1");
		if ($existing_id) {
			$wpdb->update($table, array('app_logo_url' => esc_url_raw($url)), array('id' => $existing_id));
		} else {
			$wpdb->insert($table, array('app_logo_url' => esc_url_raw($url)));
		}

		return array('app_logo_url' => $url);
	}

	public function upload_header_photo($request) {
		// Validate file
		if (!isset($_FILES['header_photo']) || $_FILES['header_photo']['error'] !== UPLOAD_ERR_OK) {
			return new WP_Error('upload_error', 'No file uploaded or upload error occurred', array('status' => 400));
		}

		$file = $_FILES['header_photo'];
		if ($file['size'] > $this->max_image_size) {
			return new WP_Error('file_too_large', 'Image exceeds 5MB limit', array('status' => 400));
		}

		$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
		if (!in_array($ext, $this->allowed_image_types)) {
			return new WP_Error('invalid_file_type', 'Only images are allowed (jpg, jpeg, png, gif, webp)', array('status' => 400));
		}

		// Ensure folder exists under uploads
		$base_dir = trailingslashit($this->upload_dir['basedir']) . $this->logo_folder;
		$base_url = trailingslashit($this->upload_dir['baseurl']) . $this->logo_folder;
		if (!file_exists($base_dir)) {
			if (!wp_mkdir_p($base_dir)) {
				return new WP_Error('dir_creation_failed', 'Failed to create settings upload directory', array('status' => 500));
			}
		}

		$filename = 'header_photo_' . time() . '_' . wp_generate_password(6, false) . '.' . $ext;
		$path = $base_dir . '/' . $filename;

		if (!move_uploaded_file($file['tmp_name'], $path)) {
			return new WP_Error('move_failed', 'Failed to move uploaded header photo', array('status' => 500));
		}

		$url = $base_url . '/' . $filename;

		// Remove previously saved header photo if it exists and is inside our settings folder
		global $wpdb;
		$settings_table = $wpdb->prefix . 'assessor_settings';
		$old_url = $wpdb->get_var("SELECT header_photo_url FROM $settings_table ORDER BY id DESC LIMIT 1");
		if (!empty($old_url) && $old_url !== $url) {
			$old_path = str_replace($this->upload_dir['baseurl'], $this->upload_dir['basedir'], $old_url);
			$old_path = wp_normalize_path($old_path);
			$safe_base = wp_normalize_path($base_dir);
			if (strpos($old_path, $safe_base) === 0 && file_exists($old_path)) {
				@unlink($old_path);
			}
		}

		// Persist to settings table
		$table = $wpdb->prefix . 'assessor_settings';
		$existing_id = $wpdb->get_var("SELECT id FROM $table ORDER BY id DESC LIMIT 1");
		if ($existing_id) {
			$wpdb->update($table, array('header_photo_url' => esc_url_raw($url)), array('id' => $existing_id));
		} else {
			$wpdb->insert($table, array('header_photo_url' => esc_url_raw($url)));
		}

		return array('header_photo_url' => $url);
	}

	public function get_property_types() {
		global $wpdb;
		$table = $wpdb->prefix . 'assessor_property_types';
		$rows = $wpdb->get_results("SELECT id, code, name, status, sort_order FROM $table WHERE status IN ('active','disabled') ORDER BY sort_order ASC, name ASC", ARRAY_A);
		return array('items' => $rows);
	}

	public function save_property_type($request) {
		$params = $request->get_json_params();
		if (!$params) {
			$params = $request->get_params();
		}
		$code = isset($params['code']) ? sanitize_text_field($params['code']) : '';
		$name = isset($params['name']) ? sanitize_text_field($params['name']) : '';
		$sort_order = isset($params['sort_order']) ? intval($params['sort_order']) : 0;
		$status = isset($params['status']) ? sanitize_text_field($params['status']) : 'active';
		if (!in_array($status, array('active','disabled'), true)) {
			$status = 'active';
		}
		if ($code === '' || $name === '') {
			return new WP_Error('invalid_input', 'Code and name are required', array('status' => 400));
		}
		global $wpdb;
		$table = $wpdb->prefix . 'assessor_property_types';
		$existing_id = isset($params['id']) ? trim(sanitize_text_field(strval($params['id']))) : '';
		if (!empty($existing_id) && $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE id = %s", $existing_id))) {
			$wpdb->update($table, array('code' => $code, 'name' => $name, 'sort_order' => $sort_order, 'status' => $status), array('id' => $existing_id), array('%s','%s','%d','%s'), array('%s'));
		} else {
			$new_id = (!empty($existing_id) && Assessor_UUID::is_valid($existing_id)) ? $existing_id : (class_exists('Assessor_UUID') ? Assessor_UUID::v7() : wp_generate_uuid4());
			$wpdb->insert($table, array('id' => $new_id, 'code' => $code, 'name' => $name, 'sort_order' => $sort_order, 'status' => $status), array('%s','%s','%s','%d','%s'));
		}
		if (class_exists('Assessor_Sync')) {
			Assessor_Sync::enqueue_config_table('assessor_property_types');
		}
		return $this->get_property_types();
	}

	public function delete_property_type($request) {
		$params = $request->get_json_params();
		if (!$params) {
			$params = $request->get_params();
		}
		$id = isset($params['id']) ? trim(sanitize_text_field(strval($params['id']))) : '';
		if (empty($id)) {
			return new WP_Error('invalid_id', 'Invalid id', array('status' => 400));
		}
		global $wpdb;
		$table = $wpdb->prefix . 'assessor_property_types';
		$wpdb->delete($table, array('id' => $id), array('%s'));
		if (class_exists('Assessor_Sync')) {
			Assessor_Sync::enqueue_config_table('assessor_property_types');
		}
		return array('success' => true);
	}

	public function get_general_classes() {
		global $wpdb;
		$table = $wpdb->prefix . 'assessor_general_classes';
		$rows = $wpdb->get_results("SELECT id, code, name, status, sort_order FROM $table WHERE status IN ('active','disabled') ORDER BY sort_order ASC, name ASC", ARRAY_A);
		return array('items' => $rows);
	}

	public function save_general_class($request) {
		$params = $request->get_json_params();
		if (!$params) {
			$params = $request->get_params();
		}
		$code = isset($params['code']) ? sanitize_text_field($params['code']) : '';
		$name = isset($params['name']) ? sanitize_text_field($params['name']) : '';
		$sort_order = isset($params['sort_order']) ? intval($params['sort_order']) : 0;
		$status = isset($params['status']) ? sanitize_text_field($params['status']) : 'active';
		if (!in_array($status, array('active','disabled'), true)) {
			$status = 'active';
		}
		if ($code === '' || $name === '') {
			return new WP_Error('invalid_input', 'Code and name are required', array('status' => 400));
		}
		global $wpdb;
		$table = $wpdb->prefix . 'assessor_general_classes';
		$existing_id = isset($params['id']) ? trim(sanitize_text_field(strval($params['id']))) : '';
		if (!empty($existing_id) && $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE id = %s", $existing_id))) {
			$wpdb->update($table, array('code' => $code, 'name' => $name, 'sort_order' => $sort_order, 'status' => $status), array('id' => $existing_id), array('%s','%s','%d','%s'), array('%s'));
		} else {
			$new_id = (!empty($existing_id) && Assessor_UUID::is_valid($existing_id)) ? $existing_id : (class_exists('Assessor_UUID') ? Assessor_UUID::v7() : wp_generate_uuid4());
			$wpdb->insert($table, array('id' => $new_id, 'code' => $code, 'name' => $name, 'sort_order' => $sort_order, 'status' => $status), array('%s','%s','%s','%d','%s'));
		}
		if (class_exists('Assessor_Sync')) {
			Assessor_Sync::enqueue_config_table('assessor_general_classes');
		}
		return $this->get_general_classes();
	}

	public function delete_general_class($request) {
		$params = $request->get_json_params();
		if (!$params) {
			$params = $request->get_params();
		}
		$id = isset($params['id']) ? trim(sanitize_text_field(strval($params['id']))) : '';
		if (empty($id)) {
			return new WP_Error('invalid_id', 'Invalid id', array('status' => 400));
		}
		global $wpdb;
		$table = $wpdb->prefix . 'assessor_general_classes';
		$wpdb->delete($table, array('id' => $id), array('%s'));
		if (class_exists('Assessor_Sync')) {
			Assessor_Sync::enqueue_config_table('assessor_general_classes');
		}
		return array('success' => true);
	}

	public function get_locations() {
		global $wpdb;
		$table = $wpdb->prefix . 'assessor_locations';
		$rows = $wpdb->get_results("SELECT id, code, name, pin, status, sort_order FROM $table WHERE status IN ('active','disabled') ORDER BY sort_order ASC, name ASC", ARRAY_A);
		return array('items' => $rows);
	}

	public function save_location($request) {
		$params = $request->get_json_params();
		if (!$params) {
			$params = $request->get_params();
		}
		$code = isset($params['code']) ? sanitize_text_field($params['code']) : '';
		$name = isset($params['name']) ? sanitize_text_field($params['name']) : '';
		$pin = isset($params['pin']) ? sanitize_text_field($params['pin']) : '';
		$sort_order = isset($params['sort_order']) ? intval($params['sort_order']) : 0;
		$status = isset($params['status']) ? sanitize_text_field($params['status']) : 'active';
		if (!in_array($status, array('active','disabled'), true)) {
			$status = 'active';
		}
		if ($code === '' || $name === '') {
			return new WP_Error('invalid_input', 'Code and name are required', array('status' => 400));
		}
		global $wpdb;
		$table = $wpdb->prefix . 'assessor_locations';
		$existing_id = isset($params['id']) ? trim(sanitize_text_field(strval($params['id']))) : '';
		if (!empty($existing_id) && $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE id = %s", $existing_id))) {
			$wpdb->update($table, array('code' => $code, 'name' => $name, 'pin' => $pin, 'sort_order' => $sort_order, 'status' => $status), array('id' => $existing_id), array('%s','%s','%s','%d','%s'), array('%s'));
		} else {
			$new_id = (!empty($existing_id) && Assessor_UUID::is_valid($existing_id)) ? $existing_id : (class_exists('Assessor_UUID') ? Assessor_UUID::v7() : wp_generate_uuid4());
			$wpdb->insert($table, array('id' => $new_id, 'code' => $code, 'name' => $name, 'pin' => $pin, 'sort_order' => $sort_order, 'status' => $status), array('%s','%s','%s','%s','%d','%s'));
		}
		if (class_exists('Assessor_Sync')) {
			Assessor_Sync::enqueue_config_table('assessor_locations');
		}
		return $this->get_locations();
	}

	public function delete_location($request) {
		$params = $request->get_json_params();
		if (!$params) {
			$params = $request->get_params();
		}
		$id = isset($params['id']) ? trim(sanitize_text_field(strval($params['id']))) : '';
		if (empty($id)) {
			return new WP_Error('invalid_id', 'Invalid id', array('status' => 400));
		}
		global $wpdb;
		$table = $wpdb->prefix . 'assessor_locations';
		$wpdb->delete($table, array('id' => $id), array('%s'));
		if (class_exists('Assessor_Sync')) {
			Assessor_Sync::enqueue_config_table('assessor_locations');
		}
		return array('success' => true);
	}

	/**
	 * Canonical Revision Resolver:
	 * Resolves a revision record by:
	 * 1. UUID v7 / string ID
	 * 2. revision_code
	 * 3. Legacy numeric ID (via mapping table assessor_revision_id_uuid_map)
	 *
	 * @param string|int $identifier
	 * @return object|null Canonical revision object
	 */
	public static function resolve_revision($identifier) {
		if (empty($identifier)) {
			return null;
		}

		global $wpdb;
		$table = $wpdb->prefix . 'assessor_revision_entries';
		$identifier_str = trim(strval($identifier));

		// 1. Direct lookup by id (UUID)
		if (class_exists('Assessor_UUID') && Assessor_UUID::is_valid($identifier_str)) {
			$row = $wpdb->get_row($wpdb->prepare(
				"SELECT * FROM $table WHERE id = %s AND status = 'active' LIMIT 1",
				$identifier_str
			));
			if ($row) {
				return $row;
			}
		}

		// 2. Direct lookup by revision_code
		$row = $wpdb->get_row($wpdb->prepare(
			"SELECT * FROM $table WHERE revision_code = %s AND status = 'active' LIMIT 1",
			$identifier_str
		));
		if ($row) {
			return $row;
		}

		// 3. Backward-compatibility: Lookup by legacy numeric ID via mapping table
		if (is_numeric($identifier_str)) {
			$table_map = $wpdb->prefix . 'assessor_revision_id_uuid_map';
			$has_map = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_map));
			if ($has_map) {
				$uuid = $wpdb->get_var($wpdb->prepare(
					"SELECT new_uuid FROM $table_map WHERE old_id = %d LIMIT 1",
					intval($identifier_str)
				));
				if ($uuid) {
					$row = $wpdb->get_row($wpdb->prepare(
						"SELECT * FROM $table WHERE id = %s AND status = 'active' LIMIT 1",
						$uuid
					));
					if ($row) {
						return $row;
					}
				}
			}
		}

		return null;
	}

	public function get_revision_entries() {
		global $wpdb;
		$table = $wpdb->prefix . 'assessor_revision_entries';
		$entries = $wpdb->get_results(
			"SELECT id, revision_code, revision_year, from_year, to_year, status, sort_order, created_at, updated_at FROM $table WHERE status = 'active' ORDER BY sort_order ASC, from_year DESC",
			ARRAY_A
		);
		return array('items' => $entries);
	}

	public function save_revision_entry($request) {
		global $wpdb;
		$table = $wpdb->prefix . 'assessor_revision_entries';
		
		$params = $request->get_json_params();
		if (!$params) {
			$params = $request->get_params();
		}

		$revision_year = sanitize_text_field($params['revision_year'] ?? '');
		$revision_code = sanitize_text_field($params['revision_code'] ?? '');
		$from_year = sanitize_text_field($params['from_year'] ?? '');
		$to_year = sanitize_text_field($params['to_year'] ?? 'present');
		$status = sanitize_text_field($params['status'] ?? 'active');
		$sort_order = intval($params['sort_order'] ?? 0);
		$id = isset($params['id']) ? trim(strval($params['id'])) : '';

		if (empty($revision_year) || empty($from_year)) {
			return new WP_Error('missing_fields', 'Revision year and from year are required', array('status' => 400));
		}

		// Ensure a clean revision_code
		if (empty($revision_code)) {
			$clean = preg_replace('/[^a-zA-Z0-9]+/', '-', trim($revision_year));
			$revision_code = strtoupper(trim($clean, '-'));
			if (empty($revision_code)) {
				$revision_code = 'REV-' . trim($from_year);
			}
		}

		$data = array(
			'revision_code' => $revision_code,
			'revision_year' => $revision_year,
			'from_year' => $from_year,
			'to_year' => $to_year,
			'status' => $status,
			'sort_order' => $sort_order,
			'updated_at' => Assessor_Timezone::now_mysql()
		);

		// Check if updating an existing entry
		$existing = null;
		if (!empty($id)) {
			$existing = self::resolve_revision($id);
			if (!$existing) {
				// Also check if id exists directly (e.g. if inactive)
				$existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %s LIMIT 1", $id));
			}
		}

		if ($existing) {
			// Update existing entry
			$wpdb->update($table, $data, array('id' => $existing->id), array('%s', '%s', '%s', '%s', '%s', '%d', '%s'), array('%s'));
		} else {
			// Insert new entry with UUID v7
			$new_id = class_exists('Assessor_UUID') ? Assessor_UUID::v7() : wp_generate_uuid4();
			$data['id'] = $new_id;
			$data['created_at'] = Assessor_Timezone::now_mysql();
			$wpdb->insert($table, $data, array('%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s'));
		}

		// Return updated list
		if (class_exists('Assessor_Sync')) {
			Assessor_Sync::enqueue_config_table('assessor_revision_entries');
		}
		return $this->get_revision_entries();
	}

	public function delete_revision_entry($request) {
		global $wpdb;
		$table = $wpdb->prefix . 'assessor_revision_entries';
		
		$params = $request->get_json_params();
		if (!$params) {
			$params = $request->get_params();
		}

		$id = isset($params['id']) ? trim(strval($params['id'])) : '';
		if (empty($id)) {
			return new WP_Error('invalid_id', 'Valid ID is required', array('status' => 400));
		}

		// Resolve canonical revision
		$existing = self::resolve_revision($id);
		if (!$existing) {
			$existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %s LIMIT 1", $id));
		}

		if (!$existing) {
			return new WP_Error('not_found', 'Revision entry not found', array('status' => 404));
		}

		$wpdb->delete($table, array('id' => $existing->id), array('%s'));
		if (class_exists('Assessor_Sync')) {
			Assessor_Sync::enqueue_config_table('assessor_revision_entries');
		}
		return array('success' => true);
	}

	// Memoranda Templates
	public function get_memoranda_templates() {
		global $wpdb;
		$table = $wpdb->prefix . 'assessor_memoranda_templates';
		$rows = $wpdb->get_results("SELECT id, title, template_text FROM $table ORDER BY id ASC", ARRAY_A);
		return array(
			'success' => true,
			'templates' => $rows ? $rows : array()
		);
	}

	public function save_memoranda_template($request) {
		global $wpdb;
		$table = $wpdb->prefix . 'assessor_memoranda_templates';
		$params = $request->get_json_params();
		if (!$params) {
			$params = $request->get_params();
		}

		$id = isset($params['id']) ? intval($params['id']) : 0;
		$title = sanitize_text_field($params['title'] ?? '');
		$template_text = sanitize_textarea_field($params['template_text'] ?? '');
		
		if (empty($title) || empty($template_text)) {
			return new WP_Error('invalid_input', 'Title and Template Text are required', array('status' => 400));
		}

		$data = array(
			'title' => $title,
			'template_text' => $template_text
		);

		if ($id > 0) {
			$wpdb->update($table, $data, array('id' => $id), array('%s', '%s'), array('%d'));
		} else {
			$wpdb->insert($table, $data, array('%s', '%s'));
		}

		if (class_exists('Assessor_Sync')) {
			Assessor_Sync::enqueue_config_table('assessor_memoranda_templates');
		}

		return $this->get_memoranda_templates();
	}

	public function delete_memoranda_template($request) {
		global $wpdb;
		$table = $wpdb->prefix . 'assessor_memoranda_templates';
		
		$params = $request->get_json_params();
		if (!$params) {
			$params = $request->get_params();
		}

		$id = intval($params['id'] ?? 0);
		if ($id <= 0) {
			return new WP_Error('invalid_id', 'Valid ID is required', array('status' => 400));
		}

		$wpdb->delete($table, array('id' => $id), array('%d'));
		
		if (class_exists('Assessor_Sync')) {
			Assessor_Sync::enqueue_config_table('assessor_memoranda_templates');
		}
		return array('success' => true);
	}

	// Request purposes (Purpose + Amount Paid)
	public function get_request_purposes() {
		global $wpdb;
		$table = $wpdb->prefix . 'assessor_request_purposes';
		$rows = $wpdb->get_results("SELECT id, purpose, amount, status, sort_order FROM $table WHERE status IN ('active','disabled') ORDER BY sort_order ASC, purpose ASC", ARRAY_A);
		return array('items' => $rows);
	}

	public function save_request_purpose($request) {
		$params = $request->get_json_params();
		if (!$params) {
			$params = $request->get_params();
		}

		$purpose = isset($params['purpose']) ? sanitize_text_field($params['purpose']) : '';
		// Normalize: store with underscores; convert spaces to underscores for consistency
		$purpose = trim(preg_replace('/\s+/', ' ', $purpose));
		$purpose = str_replace(' ', '_', $purpose);
		$amount = isset($params['amount']) ? $params['amount'] : 0;
		$status = isset($params['status']) ? sanitize_text_field($params['status']) : 'active';
		$sort_order = isset($params['sort_order']) ? intval($params['sort_order']) : 0;
		$id = isset($params['id']) ? trim(sanitize_text_field(strval($params['id']))) : '';

		if ($purpose === '') {
			return new WP_Error('invalid_input', 'Purpose is required', array('status' => 400));
		}
		if (!is_numeric($amount)) {
			return new WP_Error('invalid_input', 'Amount must be numeric', array('status' => 400));
		}
		$amount = round((float)$amount, 2);
		if ($amount < 0) {
			return new WP_Error('invalid_input', 'Amount cannot be negative', array('status' => 400));
		}
		if (!in_array($status, array('active','disabled'), true)) {
			$status = 'active';
		}

		global $wpdb;
		$table = $wpdb->prefix . 'assessor_request_purposes';

		// Prevent duplicates (case-insensitive)
		$existing = $wpdb->get_row($wpdb->prepare("SELECT id FROM $table WHERE LOWER(purpose) = LOWER(%s) LIMIT 1", $purpose), ARRAY_A);
		if ($existing && strval($existing['id']) !== $id) {
			return new WP_Error('duplicate_purpose', 'Purpose already exists', array('status' => 400, 'code' => 'duplicate_purpose'));
		}

		$data = array(
			'purpose' => $purpose,
			'amount' => $amount,
			'status' => $status,
			'sort_order' => $sort_order,
			'updated_at' => Assessor_Timezone::now_mysql()
		);

		if (!empty($id) && $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE id = %s", $id))) {
			$wpdb->update($table, $data, array('id' => $id), array('%s','%f','%s','%d','%s'), array('%s'));
		} else {
			$new_id = (!empty($id) && Assessor_UUID::is_valid($id)) ? $id : (class_exists('Assessor_UUID') ? Assessor_UUID::v7() : wp_generate_uuid4());
			$data['id'] = $new_id;
			$data['created_at'] = Assessor_Timezone::now_mysql();
			$wpdb->insert($table, $data, array('%s','%f','%s','%d','%s','%s','%s'));
		}
		if (class_exists('Assessor_Sync')) {
			Assessor_Sync::enqueue_config_table('assessor_request_purposes');
		}

		return $this->get_request_purposes();
	}

	public function delete_request_purpose($request) {
		$params = $request->get_json_params();
		if (!$params) {
			$params = $request->get_params();
		}
		$id = isset($params['id']) ? trim(sanitize_text_field(strval($params['id']))) : '';
		if (empty($id)) {
			return new WP_Error('invalid_id', 'Invalid id', array('status' => 400));
		}

		global $wpdb;
		$table = $wpdb->prefix . 'assessor_request_purposes';
		$wpdb->delete($table, array('id' => $id), array('%s'));
		if (class_exists('Assessor_Sync')) {
			Assessor_Sync::enqueue_config_table('assessor_request_purposes');
		}
		return array('success' => true);
	}
}


