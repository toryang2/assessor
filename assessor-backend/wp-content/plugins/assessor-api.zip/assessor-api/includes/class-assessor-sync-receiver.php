<?php

/**
 * Assessor Sync Receiver
 *
 * Runs on the LIVE website. Exposes REST endpoints consumed by local builds:
 *
 *   GET  /assessor/v1/sync/health     — connectivity ping (public, no auth)
 *   POST /assessor/v1/sync/push       — receive batch of property records from local
 *   GET  /assessor/v1/sync/pull       — serve records changed since ?since= to local
 *
 * Authentication: X-Sync-Token header must match ASSESSOR_SYNC_TOKEN in wp-config.php.
 * Both the local site and the live site must define the same token value.
 */
class Assessor_Sync_Receiver {

    // -------------------------------------------------------------------------
    // Token authentication
    // -------------------------------------------------------------------------

    /**
     * Permission callback for sync endpoints.
     * Returns true when X-Sync-Token matches the configured constant.
     */
    public function verify_sync_token($request) {
        if (!defined('ASSESSOR_SYNC_TOKEN') || empty(ASSESSOR_SYNC_TOKEN)) {
            return new WP_Error(
                'sync_not_configured',
                'Sync token is not configured on this server. Add define(\'ASSESSOR_SYNC_TOKEN\', \'...\') to wp-config.php.',
                array('status' => 503)
            );
        }

        $token = $request->get_header('x_sync_token');
        if (empty($token)) {
            $token = $request->get_header('x-sync-token');
        }

        if (empty($token) || !hash_equals((string) ASSESSOR_SYNC_TOKEN, (string) $token)) {
            return new WP_Error('invalid_sync_token', 'Invalid or missing X-Sync-Token.', array('status' => 403));
        }

        return true;
    }

    // -------------------------------------------------------------------------
    // GET /assessor/v1/sync/health
    // -------------------------------------------------------------------------

    /**
     * Lightweight health check — no auth required.
     * Local builds use this to test connectivity before attempting push/pull.
     */
    public function health($request) {
        return array(
            'status'    => 'ok',
            'server_ts' => current_time('mysql'),
        );
    }

    // -------------------------------------------------------------------------
    // POST /assessor/v1/sync/push
    // -------------------------------------------------------------------------

    /**
     * Receive a batch of property records from a local build and upsert them.
     * Applies last-write-wins: skips any record where local updated_at <= live updated_at.
     *
     * Request body: { "records": [ { property fields... }, ... ] }
     *
     * Response: {
     *   "results": {
     *     "<tax_declaration_number>": { "status": "synced"|"skipped"|"error", "message": "..." }
     *   },
     *   "summary": { "synced": N, "skipped": N, "errors": N }
     * }
     */
    public function receive_push($request) {
        $params  = $request->get_json_params();
        $records = isset($params['records']) ? $params['records'] : array();

        if (!is_array($records) || empty($records)) {
            return new WP_Error('no_records', 'No records provided in request body.', array('status' => 400));
        }

        // Cap batch size to prevent abuse
        if (count($records) > 200) {
            return new WP_Error('batch_too_large', 'Maximum 200 records per push request.', array('status' => 400));
        }

        global $wpdb;
        $table = $wpdb->prefix . 'assessor_properties';

        $results = array();
        $synced  = 0;
        $skipped = 0;
        $errors  = 0;

        foreach ($records as $record) {
            if (!is_array($record)) {
                continue;
            }

            // Check if this record is a request
            $record_type = isset($record['_record_type']) ? $record['_record_type'] : '';
            if (empty($record_type) && isset($record['receipt_number']) && !isset($record['tax_declaration_number'])) {
                $record_type = 'request';
            }

            if ($record_type === 'request') {
                $table_requests = $wpdb->prefix . 'assessor_requests';
                $result = $this->upsert_request($record, $table_requests, $wpdb);
                $req_id = isset($record['id']) ? trim((string)$record['id']) : '';
                $key = !empty($req_id) ? $req_id : '__missing_req_id_' . ($errors + 1);
                $results[$key] = $result;

                if ($result['status'] === 'synced') {
                    $synced++;
                } elseif ($result['status'] === 'skipped') {
                    $skipped++;
                } else {
                    $errors++;
                }
                continue;
            }

            $tax_num = isset($record['tax_declaration_number']) ? trim($record['tax_declaration_number']) : '';
            if ($tax_num === '') {
                $errors++;
                $results['__missing_tdn_' . $errors] = array(
                    'status'  => 'error',
                    'message' => 'Missing tax_declaration_number',
                );
                continue;
            }

            $result = $this->upsert_property($record, $table, $wpdb);

            $prop_id = isset($record['id']) ? trim((string)$record['id']) : '';
            $key = !empty($prop_id) ? $prop_id : $tax_num;
            $results[$key] = $result;
            // Also store under TDN for backward compatibility if not colliding
            if (!empty($tax_num) && !isset($results[$tax_num])) {
                $results[$tax_num] = $result;
            }
            if ($result['status'] === 'synced') {
                $synced++;
            } elseif ($result['status'] === 'skipped') {
                $skipped++;
            } else {
                $errors++;
            }
        }

        update_option('assessor_last_local_push', current_time('mysql'));

        return array(
            'results' => $results,
            'summary' => array(
                'synced'  => $synced,
                'skipped' => $skipped,
                'errors'  => $errors,
            ),
        );
    }

    /**
     * Upsert a single property record with last-write-wins.
     *
     * @return array { status: 'synced'|'skipped'|'error', message?: string }
     */
    private function upsert_property($record, $table, $wpdb) {
        $tax_num = trim($record['tax_declaration_number']);
        $prop_id = isset($record['id']) ? trim((string)$record['id']) : '';
        $revision_id = isset($record['revision_id']) && !empty($record['revision_id']) ? trim((string)$record['revision_id']) : null;

        // Exact match by UUID first
        $existing = null;
        if (!empty($prop_id)) {
            $existing = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT id, updated_at FROM $table WHERE id = %s LIMIT 1",
                    $prop_id
                ),
                ARRAY_A
            );
        }

        // Secondary fallback: match by (tax_declaration_number, revision_id) if UUID didn't match
        if (!$existing && !empty($tax_num) && !empty($revision_id)) {
            $existing = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT id, updated_at FROM $table WHERE tax_declaration_number = %s AND revision_id = %s LIMIT 1",
                    $tax_num,
                    $revision_id
                ),
                ARRAY_A
            );
        }

        $remote_ts   = isset($record['updated_at']) ? strtotime($record['updated_at']) : 0;
        $existing_ts = $existing ? strtotime($existing['updated_at']) : 0;

        // Skip if live record is same age or newer (live wins)
        if ($existing && $existing_ts >= $remote_ts) {
            return array('status' => 'skipped', 'message' => 'Live record is up to date');
        }

        $property_state = isset($record['property_state'])
            ? strtoupper(trim((string)$record['property_state']))
            : null;

        $record_for_property = $record;
        if ($property_state !== null) {
            unset($record_for_property['property_state']);
        }

        $safe = $this->sanitize_incoming_record($record_for_property);

        if ($existing) {
            // UPDATE existing record
            $updated = $wpdb->update($table, $safe, array('id' => $existing['id']), null, array('%s'));
            if ($updated === false) {
                return array('status' => 'error', 'message' => $wpdb->last_error);
            }
            $live_property_id = $existing['id'];
        } else {
            // INSERT new record (preserve incoming UUID v7 from local build, or generate fresh one)
            if (empty($safe['id'])) {
                $safe['id'] = class_exists('Assessor_UUID') ? Assessor_UUID::v7() : wp_generate_uuid4();
            }
            if (empty($safe['created_by'])) {
                $safe['created_by'] = null;
            }
            if (empty($safe['updated_by'])) {
                $safe['updated_by'] = null;
            }
            $inserted = $wpdb->insert($table, $safe);
            if ($inserted === false) {
                return array('status' => 'error', 'message' => $wpdb->last_error);
            }
            $live_property_id = $safe['id'];
        }

        if (class_exists('Assessor_Audit')) {
            $audit = new Assessor_Audit();
            $audit->log_activity(0, 'SYNC_FROM_LOCAL', $table, $live_property_id, null, array('tax_declaration_number' => $tax_num));
        }

        // Process pushed documents
        if (!empty($record['assessor_documents']) && is_array($record['assessor_documents'])) {
            $table_docs = $wpdb->prefix . 'assessor_documents';
            $upload_dir = wp_upload_dir();
            $base_dir = $upload_dir['basedir'] . '/assessor-documents';
            
            $tdn_safe = preg_replace('/[^A-Za-z0-9_.\-]/', '_', $tax_num);
            $prop_id_safe = preg_replace('/[^A-Za-z0-9_\-]/', '_', (string)$live_property_id);
            if (!empty($tdn_safe) && !empty($prop_id_safe)) {
                $folder_name = $tdn_safe . '_' . $prop_id_safe;
            } elseif (!empty($tdn_safe)) {
                $folder_name = $tdn_safe;
            } elseif (!empty($prop_id_safe)) {
                $folder_name = $prop_id_safe;
            } else {
                $folder_name = 'unknown';
            }
            $property_dir = $base_dir . '/' . $folder_name;
            if (!file_exists($property_dir)) {
                wp_mkdir_p($property_dir);
            }
            
            foreach ($record['assessor_documents'] as $doc) {
                $existing_doc = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table_docs WHERE filename = %s LIMIT 1", $doc['filename']));
                
                if (!empty($doc['file_data']) && !$existing_doc) {
                    $file_data = base64_decode($doc['file_data']);
                    if ($file_data !== false) {
                        $file_path = $property_dir . '/' . sanitize_file_name($doc['filename']);
                        file_put_contents($file_path, $file_data);
                        
                        $wpdb->insert($table_docs, array(
                            'property_id' => $live_property_id,
                            'filename' => sanitize_file_name($doc['filename']),
                            'original_filename' => sanitize_text_field($doc['original_filename']),
                            'file_path' => $file_path,
                            'file_type' => sanitize_text_field($doc['file_type']),
                            'description' => sanitize_textarea_field($doc['description'] ?? ''),
                            'uploaded_by' => 0
                        ), array('%s', '%s', '%s', '%s', '%s', '%s', '%s'));
                    }
                }
            }
        }

        // Sync property state if provided
        if ($property_state !== null && $property_state !== '') {
            $table_property_states = $wpdb->prefix . 'assessor_property_states';
            $wpdb->replace($table_property_states, array(
                'property_id' => $live_property_id,
                'state'       => $property_state,
            ), array('%s', '%s'));
        }

        return array('status' => 'synced');
    }

    /**
     * Upsert a single request record with last-write-wins and soft-delete support.
     *
     * @return array { status: 'synced'|'skipped'|'error', message?: string }
     */
    private function upsert_request($record, $table, $wpdb) {
        $req_id = isset($record['id']) ? trim((string)$record['id']) : '';
        if (empty($req_id)) {
            return array('status' => 'error', 'message' => 'Missing request ID (UUID)');
        }

        // Exact match by UUID
        $existing = $wpdb->get_row(
            $wpdb->prepare("SELECT id, updated_at, deleted_at FROM $table WHERE id = %s LIMIT 1", $req_id),
            ARRAY_A
        );

        $remote_ts   = isset($record['updated_at']) ? strtotime($record['updated_at']) : 0;
        $existing_ts = $existing ? strtotime($existing['updated_at']) : 0;

        // Skip if live record is same age or newer (live wins)
        if ($existing && $existing_ts >= $remote_ts) {
            return array('status' => 'skipped', 'message' => 'Live record is up to date');
        }

        $safe = $this->sanitize_incoming_request_record($record);

        if ($existing) {
            // UPDATE existing record
            $updated = $wpdb->update($table, $safe, array('id' => $existing['id']), null, array('%s'));
            if ($updated === false) {
                return array('status' => 'error', 'message' => $wpdb->last_error);
            }
        } else {
            // INSERT new record (preserve incoming UUID v7!)
            $inserted = $wpdb->insert($table, $safe);
            if ($inserted === false) {
                return array('status' => 'error', 'message' => $wpdb->last_error);
            }
        }

        if (class_exists('Assessor_Audit')) {
            $audit = new Assessor_Audit();
            $action = !empty($safe['deleted_at']) ? 'SYNC_DELETE_REQUEST' : 'SYNC_REQUEST_FROM_LOCAL';
            $audit->log_activity(0, $action, $table, $req_id, null, array('receipt_number' => $record['receipt_number'] ?? ''));
        }

        return array('status' => 'synced');
    }

    // -------------------------------------------------------------------------
    // GET /assessor/v1/sync/pull
    // -------------------------------------------------------------------------

    /**
     * Return all property records updated since ?since= (MySQL datetime string).
     * The local build calls this after a push to get any changes made directly on live.
     *
     * Query params:
     *   since  (required) — MySQL datetime e.g. "2025-01-01 00:00:00"
     *   limit  (optional) — default 500, max 1000
     *
     * Response: { "records": [ { ... }, ... ], "count": N, "since": "...", "server_ts": "..." }
     */
    public function serve_pull($request) {
        $params = $request->get_params();

        $since = isset($params['since']) ? sanitize_text_field($params['since']) : '';
        if (empty($since)) {
            return new WP_Error('missing_since', 'Query parameter "since" is required (MySQL datetime).', array('status' => 400));
        }

        // Validate datetime format loosely
        if (!preg_match('/^\d{4}-\d{2}-\d{2}/', $since)) {
            return new WP_Error('invalid_since', '"since" must be a valid datetime string (YYYY-MM-DD ...).', array('status' => 400));
        }

        $limit  = isset($params['limit']) ? min(2000, max(1, intval($params['limit']))) : 500;
        $offset = isset($params['offset']) ? max(0, intval($params['offset'])) : 0;

        $type = isset($params['type']) ? sanitize_text_field($params['type']) : 'properties';

        global $wpdb;

        if ($type === 'users') {
            $table_users = $wpdb->prefix . 'assessor_users';
            $records = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM $table_users ORDER BY id ASC LIMIT %d OFFSET %d",
                    $limit,
                    $offset
                ),
                ARRAY_A
            );
            
            return array(
                'records'   => $records ?: array(),
                'count'     => count($records ?: array()),
                'since'     => $since,
                'server_ts' => current_time('mysql'),
            );
        }

        if ($type === 'requests') {
            $table_requests = $wpdb->prefix . 'assessor_requests';
            // Pull records updated since $since, including soft-deleted ones (deleted_at IS NOT NULL)
            $records = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM $table_requests WHERE updated_at > %s ORDER BY updated_at ASC, id ASC LIMIT %d OFFSET %d",
                    $since,
                    $limit,
                    $offset
                ),
                ARRAY_A
            );

            $safe_records = array();
            if ($records) {
                foreach ($records as $record) {
                    $safe = $this->sanitize_outgoing_request_record($record);
                    $safe['_record_type'] = 'request';
                    $safe_records[] = $safe;
                }
            }

            update_option('assessor_last_local_pull_requests', current_time('mysql'));

            return array(
                'records'   => $safe_records,
                'count'     => count($safe_records),
                'since'     => $since,
                'server_ts' => current_time('mysql'),
            );
        }

        $table = $wpdb->prefix . 'assessor_properties';

        $records = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM $table WHERE updated_at > %s ORDER BY updated_at ASC LIMIT %d OFFSET %d",
                $since,
                $limit,
                $offset
            ),
            ARRAY_A
        );

        if ($records === null) {
            $records = array();
        }

        $table_docs = $wpdb->prefix . 'assessor_documents';

        // Strip internal IDs that should not overwrite local user assignments
        $safe_records = array();
        foreach ($records as $record) {
            $safe = $this->sanitize_outgoing_record($record);
            
            // Attach documents metadata (excluding local-only uploaded_by)
            $docs = $wpdb->get_results(
                $wpdb->prepare("SELECT filename, original_filename, file_path, file_type, description, uploaded_at FROM $table_docs WHERE property_id = %s", $record['id']),
                ARRAY_A
            );
            $safe['assessor_documents'] = $docs ? $docs : array();
            
            // Attach property state
            $table_states = $wpdb->prefix . 'assessor_property_states';
            $property_state = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT state
                     FROM $table_states
                     WHERE property_id = %s
                     LIMIT 1",
                    $record['id']
                )
            );

            $safe['property_state'] = $property_state !== null
                ? strtoupper(trim($property_state))
                : 'CURRENT';

            error_log(
                'Assessor Sync Pull: property_id=' . $record['id'] .
                ' tax_declaration_number=' . ($record['tax_declaration_number'] ?? '') .
                ' property_state=' . ($safe['property_state'] ?? 'NULL')
            );
            
            $safe_records[] = $safe;
        }

        update_option('assessor_last_local_pull', current_time('mysql'));

        return array(
            'records'   => $safe_records,
            'count'     => count($safe_records),
            'since'     => $since,
            'server_ts' => current_time('mysql'),
        );
    }

    // -------------------------------------------------------------------------
    // POST /assessor/v1/sync/push-config
    // -------------------------------------------------------------------------

    /**
     * Receive a full snapshot of a config table from a local build and replace it on live.
     *
     * Strategy: DELETE all rows from the live table, then INSERT all received rows.
     * This is safe because config tables are small and local is authoritative.
     *
     * Request body: { "table": "assessor_general_classes", "rows": [ {...}, ... ] }
     * Response:     { "table": "...", "inserted": N, "server_ts": "..." }
     */
    public function receive_config_push($request) {
        $params = $request->get_json_params();

        $table_suffix = isset($params['table']) ? sanitize_key($params['table']) : '';
        $rows         = isset($params['rows'])  ? $params['rows']                : array();

        // Whitelist: only allow known config tables — never let arbitrary table names through
        $allowed_tables = array(
            'assessor_general_classes',
            'assessor_locations',
            'assessor_property_types',
            'assessor_request_purposes',
            'assessor_revision_entries',
        );

        if (!in_array($table_suffix, $allowed_tables, true)) {
            return new WP_Error(
                'invalid_table',
                "Table '$table_suffix' is not allowed for config sync.",
                array('status' => 400)
            );
        }

        if (!is_array($rows)) {
            return new WP_Error('invalid_rows', 'rows must be an array.', array('status' => 400));
        }

        global $wpdb;
        $table = $wpdb->prefix . $table_suffix;

        // Instead of wiping the live table (which deletes barangays added on live),
        // we will upsert (replace) records based on their unique keys.
        $inserted = 0;
        foreach ($rows as $row) {
            if (!is_array($row) || empty($row)) {
                continue;
            }
            // Only allow scalar values — strip any nested arrays
            $clean = array_filter($row, 'is_scalar');
            if (empty($clean)) {
                continue;
            }
            
            // Remove 'id' so it matches on the UNIQUE keys (code, purpose, etc.) rather than overwriting unrelated IDs
            if (isset($clean['id'])) {
                unset($clean['id']);
            }

            // wpdb->replace uses REPLACE INTO, which updates if unique key exists, or inserts if not
            $result = $wpdb->replace($table, $clean);
            if ($result !== false) {
                $inserted++;
            }
        }

        return array(
            'table'     => $table_suffix,
            'inserted'  => $inserted,
            'server_ts' => current_time('mysql'),
        );
    }

    // -------------------------------------------------------------------------
    // Sanitization helpers
    // -------------------------------------------------------------------------

    /**
     * Columns accepted from an incoming (local -> live) push.
     * Includes local user IDs so that authorship is preserved on the live site.
     */
    private function sanitize_incoming_record($record) {
        $allowed = array(
            'id', 'tax_declaration_number', 'previous_tax_declaration_number',
            'declarant_last_name', 'declarant_first_name', 'declarant_middle_initial',
            'business', 'business_name', 'location', 'lot_number',
            'unique_lot_number_identified', 'survey_number',
            'area_hectare', 'area_hectare_old', 'area_sqm', 'title_number',
            'assessed_value', 'assessed_value_old', 'effectivity_date',
            'pin', 'address', 'assessment_date',
            'kind_of_property', 'gen_class', 'memoranda', 'supporting_documents',
            'supporting_documents_old', 'change_reason',
            'verifier_signatory_name', 'verifier_signatory_title',
            'municipal_assessor_name', 'municipal_assessor_suffix',
            'municipal_assessor_title', 'municipal_assessor_license',
            'status', 'revision_id', 'updated_at', 'created_at',
            'created_by', 'updated_by', 'property_state'
        );

        $safe = array();
        foreach ($allowed as $col) {
            if (array_key_exists($col, $record)) {
                $safe[$col] = $record[$col];
            }
        }
        return $safe;
    }

    /**
     * Columns sent to local builds in a pull response.
     * Includes local user IDs so authorship is preserved.
     */
    private function sanitize_outgoing_record($record) {
        $allowed = array(
            'id', 'tax_declaration_number', 'previous_tax_declaration_number',
            'declarant_last_name', 'declarant_first_name', 'declarant_middle_initial',
            'business', 'business_name', 'location', 'lot_number',
            'unique_lot_number_identified', 'survey_number',
            'area_hectare', 'area_hectare_old', 'area_sqm', 'title_number',
            'assessed_value', 'assessed_value_old', 'effectivity_date',
            'pin', 'address', 'assessment_date',
            'kind_of_property', 'gen_class', 'memoranda', 'supporting_documents',
            'supporting_documents_old', 'change_reason',
            'verifier_signatory_name', 'verifier_signatory_title',
            'municipal_assessor_name', 'municipal_assessor_suffix',
            'municipal_assessor_title', 'municipal_assessor_license',
            'status', 'revision_id', 'updated_at', 'created_at',
            'created_by', 'updated_by', 'property_state'
        );

        $safe = array();
        foreach ($allowed as $col) {
            if (array_key_exists($col, $record)) {
                $safe[$col] = $record[$col];
            }
        }
        return $safe;
    }

    /**
     * Columns accepted from an incoming (local -> live) request push.
     */
    private function sanitize_incoming_request_record($record) {
        $allowed = array(
            'id', 'property_id', 'amount_paid', 'receipt_number',
            'is_official_request', 'date_issued', 'place_issued',
            'prepared_by', 'payment_type', 'purpose', 'client_name',
            'client_address', 'contact_number', 'email', 'remarks',
            'created_at', 'updated_at', 'created_by', 'updated_by',
            'deleted_at',
            'verifier_signatory_name', 'verifier_signatory_title',
            'municipal_assessor_name', 'municipal_assessor_suffix',
            'municipal_assessor_title', 'municipal_assessor_license'
        );

        $safe = array();
        foreach ($allowed as $col) {
            if (array_key_exists($col, $record)) {
                $safe[$col] = $record[$col];
            }
        }
        return $safe;
    }

    /**
     * Columns sent to local builds in a request pull response.
     */
    private function sanitize_outgoing_request_record($record) {
        $allowed = array(
            'id', 'property_id', 'amount_paid', 'receipt_number',
            'is_official_request', 'date_issued', 'place_issued',
            'prepared_by', 'payment_type', 'purpose', 'client_name',
            'client_address', 'contact_number', 'email', 'remarks',
            'created_at', 'updated_at', 'created_by', 'updated_by',
            'deleted_at',
            'verifier_signatory_name', 'verifier_signatory_title',
            'municipal_assessor_name', 'municipal_assessor_suffix',
            'municipal_assessor_title', 'municipal_assessor_license'
        );

        $safe = array();
        foreach ($allowed as $col) {
            if (array_key_exists($col, $record)) {
                $safe[$col] = $record[$col];
            }
        }
        return $safe;
    }

    /**
     * GET /assessor/v1/sync/revision-entries
     * Serve all revision entries from live site to local.
     */
    public function serve_revision_entries($request) {
        global $wpdb;

        $table = $wpdb->prefix . 'assessor_revision_entries';

        $rows = $wpdb->get_results(
            "SELECT
                id,
                revision_code,
                revision_year,
                from_year,
                to_year,
                status,
                sort_order,
                created_at,
                updated_at
             FROM $table
             ORDER BY sort_order ASC, id ASC",
            ARRAY_A
        );

        if ($rows === null) {
            $rows = array();
        }

        return array(
            'records'   => $rows,
            'count'     => count($rows),
            'server_ts' => current_time('mysql'),
        );
    }
}

