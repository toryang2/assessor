<?php

class Assessor_Etracs_Sync {

    public static function ensure_schema() {
        // Schema is handled by class-assessor-database.php
        // No longer modifying local tables to add etracs_objid
    }

    public static function update_progress($message) {
        update_option('assessor_sync_progress', $message, false);
    }

    public static function trigger_sync() {
        set_time_limit(0); // Prevent PHP execution timeout
        self::update_progress("Starting sync...");
        self::ensure_schema();

        $host = get_option('assessor_etracs_db_host', 'localhost');
        $port = get_option('assessor_etracs_db_port', '3306');
        $user = get_option('assessor_etracs_db_user', 'root');
        $pass = get_option('assessor_etracs_db_password', '');
        $db   = get_option('assessor_etracs_db_name', 'etracs254_kitaotao');

        if (empty($host) || empty($db) || empty($user)) {
            return new WP_Error('missing_config', 'ETRACS database configuration is incomplete.', array('status' => 400));
        }

        try {
            $dsn = "mysql:host=$host;port=$port;dbname=$db;charset=utf8mb4";
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];
            $pdo = new PDO($dsn, $user, $pass, $options);
        } catch (PDOException $e) {
            return new WP_Error('db_connect_failed', 'Failed to connect to ETRACS Database: ' . $e->getMessage(), array('status' => 500));
        }

        global $wpdb;
        $stats = [
            'entity' => 0,
            'real_property' => 0,
            'rpu' => 0,
            'faas' => 0
        ];

        // We will sync everything in this basic implementation to ensure consistency.
        // For production, we can optimize by only syncing where txntimestamp/sys_lastupdate > last_sync
        
        $wp_entity = $wpdb->prefix . 'assessor_entity';
        $wp_rp = $wpdb->prefix . 'assessor_real_property';
        $wp_rpu = $wpdb->prefix . 'assessor_rpu';
        $wp_faas = $wpdb->prefix . 'assessor_faas';

        // 1. Entity Sync
        $stmt = $pdo->query("SELECT * FROM entity");
        while ($row = $stmt->fetch()) {
            $wpdb->replace($wp_entity, [
                'objid' => $row['objid'],
                'entityno' => $row['entityno'],
                'name' => $row['name'],
                'address_text' => $row['address_text'],
                'mailingaddress' => $row['mailingaddress'],
                'type' => $row['type'],
                'sys_lastupdate' => $row['sys_lastupdate'],
                'sys_lastupdateby' => $row['sys_lastupdateby'],
                'remarks' => $row['remarks'],
                'entityname' => $row['entityname'],
                'address_objid' => $row['address_objid'],
                'mobileno' => $row['mobileno'],
                'phoneno' => $row['phoneno'],
                'email' => $row['email'],
                'state' => $row['state'],
            ]);
            $stats['entity']++;
            if ($stats['entity'] % 500 === 0) self::update_progress("Syncing Entities ({$stats['entity']} rows)...");
        }

        // 2. Real Property Sync
        $stmt = $pdo->query("
            SELECT rp.*, b.name as barangay_name 
            FROM realproperty rp 
            LEFT JOIN barangay b ON rp.barangayid = b.objid
        ");
        while ($row = $stmt->fetch()) {
            $data = [
                'objid' => $row['objid'],
                'pin' => $row['pin'],
                'cadastrallotno' => $row['cadastrallotno'],
                'surveyno' => $row['surveyno'],
                'blockno' => $row['blockno'],
                'barangay' => !empty($row['barangay_name']) ? $row['barangay_name'] : $row['barangayid'],
                'municipality' => $row['lgutype'] == 'municipality' ? $row['lguid'] : '',
                'north' => $row['north'],
                'south' => $row['south'],
                'east' => $row['east'],
                'west' => $row['west'],
                'pintype' => $row['pintype'],
                'ry' => $row['ry'],
                'barangayid' => $row['barangayid'],
                'lguid' => $row['lguid'],
                'lgutype' => $row['lgutype'],
                'purok' => $row['purok'],
                'street' => $row['street'],
                'stewardshipno' => $row['stewardshipno'],
                'portionof' => $row['portionof'],
                'autonumber' => $row['autonumber'],
                'previd' => $row['previd'],
                'claimno' => $row['claimno'],
                'section' => $row['section'],
                'parcel' => $row['parcel'],
            ];
            
            $wpdb->replace($wp_rp, $data);
            
            $stats['real_property']++;
            if ($stats['real_property'] % 500 === 0) self::update_progress("Syncing Real Properties ({$stats['real_property']} rows)...");
        }

        // 3. RPU Sync
        $stmt = $pdo->query("
            SELECT rpu.*, pc.code as class_code, rp2.barangayid as rp_barangayid
            FROM rpu 
            LEFT JOIN propertyclassification pc ON rpu.classification_objid = pc.objid
            LEFT JOIN realproperty rp2 ON rpu.realpropertyid = rp2.objid
        ");
        while ($row = $stmt->fetch()) {
            $data = [
                'objid' => $row['objid'],
                'state' => $row['state'],
                'realpropertyid' => $row['realpropertyid'],
                'rpu_type' => $row['rputype'],
                'classification' => !empty($row['class_code']) ? $row['class_code'] : $row['classification_objid'],
                'ry' => $row['ry'],
                'total_market_value' => floatval($row['totalmv']),
                'total_assessed_value' => floatval($row['totalav']),
                'taxable' => $row['taxable'],
                'total_area_hectare' => floatval($row['totalareaha']),
                'total_area_sqm' => floatval($row['totalareasqm']),
                'fullpin' => $row['fullpin'],
                'suffix' => intval($row['suffix']),
                'subsuffix' => $row['subsuffix'],
                'classification_objid' => $row['classification_objid'],
                'exemptiontype_objid' => $row['exemptiontype_objid'],
                'totalbmv' => floatval($row['totalbmv']),
                'previd' => $row['previd'],
                'rpumasterid' => $row['rpumasterid'],
                'barangayid' => $row['rp_barangayid'] ?? '',
            ];
            
            $wpdb->replace($wp_rpu, $data);
            
            $stats['rpu']++;
            if ($stats['rpu'] % 500 === 0) self::update_progress("Syncing RPUs ({$stats['rpu']} rows)...");
        }

        // 4. FAAS Sync
        // It's safer to map rxntypes and classification, but for now we pull raw data
        $stmt = $pdo->query("SELECT * FROM faas");
        while ($row = $stmt->fetch()) {
            
            $data = [
                'objid' => $row['objid'],
                'state' => $row['state'],
                'rpuid' => $row['rpuid'],
                'realpropertyid' => $row['realpropertyid'],
                'datacapture' => $row['datacapture'],
                'autonumber' => $row['autonumber'],
                'utdno' => $row['utdno'],
                'tdno' => $row['tdno'],
                'txntype_objid' => $row['txntype_objid'],
                'effectivityyear' => $row['effectivityyear'],
                'effectivityqtr' => $row['effectivityqtr'],
                'titletype' => $row['titletype'],
                'titleno' => $row['titleno'],
                'titledate' => $row['titledate'],
                'taxpayer_objid' => $row['taxpayer_objid'],
                'owner_name' => $row['owner_name'],
                'owner_address' => $row['owner_address'],
                'administrator_objid' => $row['administrator_objid'],
                'administrator_name' => $row['administrator_name'],
                'administrator_address' => $row['administrator_address'],
                'beneficiary_objid' => $row['beneficiary_objid'],
                'beneficiary_name' => $row['beneficiary_name'],
                'beneficiary_address' => $row['beneficiary_address'],
                'memoranda' => $row['memoranda'],
                'cancelnote' => $row['cancelnote'],
                'restrictionid' => $row['restrictionid'],
                'backtaxyrs' => $row['backtaxyrs'],
                'prevtdno' => $row['prevtdno'],
                'prevpin' => $row['prevpin'],
                'prevowner' => $row['prevowner'],
                'prevav' => $row['prevav'],
                'prevmv' => $row['prevmv'],
                'cancelreason' => $row['cancelreason'],
                'canceldate' => $row['canceldate'],
                'cancelledbytdnos' => $row['cancelledbytdnos'],
                'lguid' => $row['lguid'],
                'publicland' => $row['publicland'],
                'txntimestamp' => $row['txntimestamp'],
                'cancelledtimestamp' => $row['cancelledtimestamp'],
                'name' => $row['name'],
                'dtapproved' => $row['dtapproved'],
                'lgutype' => $row['lgutype'],
                'signatories' => $row['signatories'],
                'ryordinanceno' => $row['ryordinanceno'],
                'ryordinancedate' => $row['ryordinancedate'],
                'prevareaha' => $row['prevareaha'],
                'prevareasqm' => $row['prevareasqm'],
                'fullpin' => $row['fullpin'],
                'preveffectivity' => $row['preveffectivity'],
                'year' => $row['year'],
                'qtr' => $row['qtr'],
                'month' => $row['month'],
                'day' => $row['day'],
                'cancelledyear' => $row['cancelledyear'],
                'cancelledqtr' => $row['cancelledqtr'],
                'cancelledmonth' => $row['cancelledmonth'],
                'cancelledday' => $row['cancelledday'],
                'prevadministrator' => $row['prevadministrator'],
                'originlguid' => $row['originlguid'],
                'parentfaasid' => $row['parentfaasid'],
            ];

            $wpdb->replace($wp_faas, $data);
            $stats['faas']++;
            if ($stats['faas'] % 500 === 0) self::update_progress("Syncing FAAS ({$stats['faas']} rows)...");
        }

        // 5. Sync detail & lookup tables (Building, Land, Mach, Misc, PlantTree, Lookups)
        $tables_to_sync_direct = [
            'faas_previous' => 'assessor_faas_previous',
            'faas_list' => 'assessor_faas_list',
            'faas_signatory' => 'assessor_faas_signatory',
            // Building detail tables
            'bldgrpu' => 'assessor_bldgrpu',
            'bldgfloor' => 'assessor_bldgfloor',
            'bldgflooradditional' => 'assessor_bldgflooradditional',
            'bldgadditionalitem' => 'assessor_bldgadditionalitem',
            'bldguse' => 'assessor_bldguse',
            'bldgstructure' => 'assessor_bldgstructure',
            'bldgrpu_structuraltype' => 'assessor_bldgrpu_structuraltype',
            'bldgtype_depreciation' => 'assessor_bldgtype_depreciation',
            // Building lookups
            'bldgkind' => 'assessor_bldgkind',
            'bldgkindbucc' => 'assessor_bldgkindbucc',
            'bldgtype' => 'assessor_bldgtype',
            'bldgrysetting' => 'assessor_bldgrysetting',
            // Land detail tables
            'landrpu' => 'assessor_landrpu',
            'landdetail' => 'assessor_landdetail',
            // Machinery detail tables
            'machrpu' => 'assessor_machrpu',
            'machdetail' => 'assessor_machdetail',
            'machine_smv' => 'assessor_machine_smv',
            // Misc detail tables
            'miscrpu' => 'assessor_miscrpu',
            'miscitem' => 'assessor_miscitem',
            'miscrpuitem' => 'assessor_miscrpuitem',
            // Plant/Tree detail tables
            'planttreerpu' => 'assessor_planttreerpu',
            // Assessment level lookups
            'landassesslevel' => 'assessor_landassesslevel',
            'bldgassesslevel' => 'assessor_bldgassesslevel',
            'machassesslevel' => 'assessor_machassesslevel',
            'planttreeassesslevel' => 'assessor_planttreeassesslevel',
            'miscassesslevel' => 'assessor_miscassesslevel',
            // General lookups
            'propertyclassification' => 'assessor_propertyclassification',
            'structure' => 'assessor_structure',
            'material' => 'assessor_material',
            'barangay' => 'assessor_barangay',
            'exemptiontype' => 'assessor_exemptiontype',
            'rpumaster' => 'assessor_rpumaster',
        ];

        foreach ($tables_to_sync_direct as $etracs_table => $local_table) {
            $full_local_table = $wpdb->prefix . $local_table;
            try {
                $valid_columns = $wpdb->get_col("DESCRIBE `$full_local_table`", 0);
                if (empty($valid_columns)) continue;
                $valid_columns_flip = array_flip($valid_columns);

                $stmt = $pdo->query("SELECT * FROM `$etracs_table`");
                if ($stmt) {
                    $stats[$local_table] = 0;
                    self::update_progress("Syncing $etracs_table...");
                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        $filtered_row = array_intersect_key($row, $valid_columns_flip);
                        $result = $wpdb->replace($full_local_table, $filtered_row);
                        
                        if ($result === false) {
                            error_log("Assessor ETRACS Sync Error replacing $etracs_table: " . $wpdb->last_error);
                        }

                        $stats[$local_table]++;
                        if ($stats[$local_table] % 500 === 0) self::update_progress("Syncing $etracs_table ({$stats[$local_table]} rows)...");
                    }
                }
            } catch (Exception $e) {
                // Ignore if table doesn't exist in ETRACS
            }
        }

        // 6. Sync rpu_assessment with JOINs to get classname and actualuse
        $wp_rpu_assessment = $wpdb->prefix . 'assessor_rpu_assessment';
        try {
            $valid_columns_ra = $wpdb->get_col("DESCRIBE `$wp_rpu_assessment`", 0);
            $valid_columns_ra_flip = !empty($valid_columns_ra) ? array_flip($valid_columns_ra) : [];

            $stmt = $pdo->query("
                SELECT ra.*, 
                       pc1.code as classcode, 
                       pc1.name as classname, 
                       COALESCE(la.name, ba.name, ma.name, pa.name, mia.name, pc2.name) as actualuse
                FROM rpu_assessment ra
                LEFT JOIN propertyclassification pc1 ON pc1.objid = ra.classification_objid
                LEFT JOIN propertyclassification pc2 ON pc2.objid = ra.actualuse_objid
                LEFT JOIN landassesslevel la ON la.objid = ra.actualuse_objid
                LEFT JOIN bldgassesslevel ba ON ba.objid = ra.actualuse_objid
                LEFT JOIN machassesslevel ma ON ma.objid = ra.actualuse_objid
                LEFT JOIN planttreeassesslevel pa ON pa.objid = ra.actualuse_objid
                LEFT JOIN miscassesslevel mia ON mia.objid = ra.actualuse_objid
            ");
            if ($stmt && !empty($valid_columns_ra_flip)) {
                $stats['rpu_assessment'] = 0;
                self::update_progress("Syncing rpu_assessment...");
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $filtered_row = array_intersect_key($row, $valid_columns_ra_flip);
                    $result = $wpdb->replace($wp_rpu_assessment, $filtered_row);
                    if ($result === false) {
                        error_log("Assessor ETRACS Sync Error replacing rpu_assessment: " . $wpdb->last_error);
                    }
                    $stats['rpu_assessment']++;
                    if ($stats['rpu_assessment'] % 500 === 0) self::update_progress("Syncing rpu_assessment ({$stats['rpu_assessment']} rows)...");
                }
            }
        } catch (Exception $e) {}

        update_option('assessor_etracs_last_sync', current_time('mysql'));
        delete_option('assessor_sync_progress');

        return $stats;
    }
}
